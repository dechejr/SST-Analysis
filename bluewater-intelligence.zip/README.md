# Blue Water Intelligence

## Structure

```
index.html                          The app itself — static, no build step
netlify.toml                        Tells Netlify where functions live
netlify/functions/test-fetch.js     Proves server-side ERDDAP fetches work
netlify/functions/currents.js       Current direction + speed, for the arrow overlay
netlify/functions/depth.js          Real depth at a single tapped point (the point-feature fix)
netlify/functions/forecast.js       The ROFFS-style fishing forecast engine
netlify/functions/regional-knowledge.js   Compiled local knowledge (seasons + named grounds)
```

## The point feature — real depth, plus save-point / home-port actions

Tapping the map already showed coordinates (pure client-side math — always
worked). It never showed depth, at all, in any form — direct report,
confirmed by reading the actual code rather than assumed: bathymetry
(GEBCO) was only ever fetched as a full grid for `forecast.js`'s structure
scoring, there was no path from a single tap to a single real value. A
separate, much smaller function (`depth.js`) fixes this — same
GEBCO_2020 ERDDAP dataset `forecast.js` already trusts for real numeric
values, just queried for one point `[(lat):(lat)][(lon):(lon)]` instead of
a whole area, which is standard ERDDAP/OPeNDAP syntax that snaps to the
dataset's nearest actual grid cell. Reports depth honestly either
direction — a tap that lands on land shows elevation instead of depth,
not a nonsensical negative number.

**What's still not fixable, and why, named directly rather than left
quiet:** temperature at a tapped point still can't be read this way. The
SST layer is a rendered image tile, and — confirmed elsewhere in this
project, six different approaches tried — the tile server never grants a
browser permission to read a pixel's value back out of a canvas. That's a
server-side policy, not a bug with a workaround; the ring-plus-gauge
comparison is the deliberate substitute, not a placeholder for something
still to be solved. Bathymetry doesn't have this problem because it was
never a rendered image to begin with — `depth.js` asks GEBCO's real data
endpoint for a real number, the same kind of request `forecast.js` already
makes successfully.

**The small button + sub-window**, as asked: the coord card's old
full-width "Set as Home Port" button is now a small icon button that opens
a modal with two parallel actions — save this point, or set it as home
port — plus an optional name field for the former (defaults to "Spot N"
if left blank). Saved points are a new, separate thing from the single
home port: a full personal list, persisted in localStorage the same
defensive way everything else here is, rendered as amber markers on the
map immediately and again on every future visit. Tapping a saved point's
marker reopens its info (name, coordinates, depth) with a delete button —
implemented via Leaflet's `popupopen` event specifically, since the
delete button doesn't exist in the DOM until the popup is actually open,
so its click handler has to be attached fresh each time rather than at
marker-creation time.

### Smaller, and anchored to the tap — not a full-width bottom sheet

The card was a fixed, full-width bottom sheet; it's now a compact
(190px), floating box that appears near the actual tapped point. Position
is computed from `map.latLngToContainerPoint()` — confirmed this and the
card share the same coordinate origin before relying on it (`.map-wrap`
is the positioning context for both, and `#map` fills it exactly via
`inset:0`, so no offset conversion was needed. Centered horizontally on
the tap, sitting just above it by default with a small gap so it doesn't
cover the exact point it's describing, flipping to below when there isn't
room above, and clamped on both axes using the card's own real current
height (`offsetHeight`, measured after content is set — not a fixed
guess, since the home-port-distance and depth lines mean height varies by
context) rather than letting it render off-screen near any edge. Tested
directly against six scenarios — dead center, all four edges, and a
degenerate tiny-screen case — before trusting the clamping logic.

Since the card's position is a fixed pixel snapshot taken at tap time,
not something that tracks the map continuously, it closes automatically
if the map starts panning or zooming (`movestart`) rather than drifting
away from the point it's actually describing — simpler and more
predictable than continuously repositioning it during a gesture.

### Distance from home port

When a home port is set, the card now shows the great-circle distance to
it (e.g. "14.2 nm from home") — the same `L.LatLng.distanceTo()` and
meters-to-nautical-miles conversion (÷1852) the measure tool already
uses, for consistency. Verified the underlying math independently before
trusting it: 1 degree of latitude computes to exactly 60.0 nm, which is
correct by definition, not an approximation. Omitted entirely, not shown
as "— nm" or similar, when no home port is set — same honesty-over-
placeholder principle used everywhere else in this app.

### A persistent marker for the home port itself

Home port previously only affected where the map opens by default —
there was no visible marker for it at all. Now shown as a small teal
house-icon marker, deliberately styled differently from the amber
saved-point dots since it's a different kind of thing (one singular
reference location, not one of potentially many personal marks), visible
immediately on load and updated the moment a new home port is set. Tapping
it reopens its info with a "Clear Home Port" option — using the exact same
popupopen event-delegation pattern already established for saved points,
since a Leaflet popup's contents don't exist in the DOM until it's
actually open, so the button's click handler has to be attached fresh
each time rather than once at marker-creation time.

## The forecast (shared toggle, not a page)

Like Depth and Currents, the forecast is a FAB button that works on top of
any page — SST, Altimetry, Chlorophyll, or True Color — rather than its
own tab. Toggling it on shows a transparent, dashed-border box on the map
showing exactly what area will be analyzed (mirroring the server's own
50-mile cap, computed independently on the client so what's shown always
matches what actually gets sent), plus the species selector and run
button. Persists across page switches the same way current arrows do.

Each numbered spot marker now has its own popup (rank, coordinates,
productivity score, narrative) — tap a point directly on the map to see
its forecast info, whether or not the results panel happens to be open.

## Florida zones — predefined regions replace the 50-mile box

The forecast area for Florida is no longer a 50x50-mile box centered
wherever the map happens to be. It's now one of **9 predefined zones** —
the same ones the [Florida Insider Fishing
Report](https://floridainsiderfishingreport.com/our-crew/) uses to
organize their own show captains: Panhandle, Northwest, Central West,
Southwest, Florida Keys, Southeast, East/Treasure Coast, Central
East/Space Coast, and Northeast. Confirmed directly from their site
rather than guessed — their "Our Crew" page lists each captain under one
of these exact zone labels, tied to real home ports (Sarasota for Central
West, Naples for Southwest, Stuart for Treasure Coast, and so on).

**How it works:** push the Forecast button same as always — no new step,
no picker to fill out. The app finds whichever zone the map is centered
on, or the nearest one if you're centered just outside all of them (open
water between two zones, for instance), and that zone's own real
boundary becomes the entire analysis area. A small label above the Run
button shows which zone will be used, updating live as you pan the map,
and the transparent area box on the map is that zone's actual boundary —
not a fixed size — so what you see before running matches what actually
gets analyzed. Bounding boxes are matched to FWC's official regional
definitions where FWC and FIFR describe the same real geography (their
Northeast/Southeast/Indian River Lagoon boundaries), widened on the
offshore side so the scoring grid can actually reach real pelagic water —
the Gulf Stream on the Atlantic side, Gulf humps and rigs on the Gulf
side — rather than stopping a few miles off the beach.

**Each zone has its own seasonal calendar**, researched the same way as
every region in this app — real search, real sources, cited in the file.
Depth varies honestly by zone: Florida Keys and Treasure Coast (the
former Sebastian Inlet research, which sits inside this zone) turned up
specifically-named, coordinate-verified spots — the Islamorada Hump, the
409 Hump, the Gulf Stream off Sebastian. Central West turned up one real
named spot, the Middle Grounds off Sarasota. The other six zones
(Panhandle, Northwest, Southwest, Southeast, Space Coast, Northeast)
didn't turn up citable named spots in this research pass, so they carry
real seasonal data but an empty or near-empty grounds list rather than
invented specificity — the same honesty principle as Sebastian's original
research. Ask, and any of these can get a deeper pass the same way Keys
and Hatteras did.

One genuinely useful thing this research surfaced: sailfish and wahoo run
in the **opposite** season in South Florida versus North Florida — winter
peak in the south, and the Panhandle/Big Bend barely see them at all by
comparison — confirmed independently across multiple zones' worth of
sources, not an assumption carried over from one zone to the next.

**Hatteras is disabled for now** (direct request) — its full research is
kept in `regional-knowledge.js` rather than deleted, so re-enabling it is
a one-line change (adding it back to the `REGIONS` registry; nothing else
needs updating, since the auto-detect logic already iterates whatever
non-FIFR regions happen to be registered rather than hardcoding a
reference to Hatteras specifically). With it disabled, **anywhere far
from the 9 Florida zones** currently falls through to the original
50-mile-box behavior with no regional layer at all — that fallback path
itself is untouched, there's just nothing registered to use it right now.
**Custom AI-built regions** (below) still work anywhere, Florida or not,
and take priority over zone auto-detection when you've actually built and
selected one, even if it happens to sit inside a Florida zone's
boundaries — see the note on priority order in that section. The app's
default map view also moved off Hatteras waters to a Florida starting
point (Treasure Coast area) to match.

**On the specific request for live Facebook/Instagram scraping:**
deliberately not built, and worth explaining why rather than silently
skipping it. Meta's platform terms prohibit automated access to page
content, it sits behind authentication and active anti-scraping measures,
and there's no legitimate API for a third party to read a captain's posts.
A scraper aimed at it would break in practice — and worse, if it ever
silently degraded into generating plausible-sounding "reports" instead of
real ones, that's a fabrication a boater could actually get hurt trusting.
The same reasoning is why zone/region *data* is hand-compiled rather than
auto-built at runtime: this function is plain Node.js with no language
model attached, so it can't actually read and understand an arbitrary web
page the way the research behind these zones was done. So the honest
split implemented instead: this registry holds the *durable* local
knowledge (seasons and named grounds, which don't change week to week,
compiled once from real sources), and the *live* half of the forecast is
the real-time oceanography the app already fetches fresh every run — SST,
chlorophyll, altimetry, currents, weather, barometric-pressure trend, and
tides. Compiled knowledge + current conditions, which is the spirit of the
request, built from data that can actually and legally be read.

**On wiring an LLM into the function itself at runtime**: this is now
built — see "AI-built custom regions" below for the full design, setup
steps, and honest tradeoffs. The short version: it's a one-time (or
periodic) background research step per region, not a call on every
forecast, which is what makes it workable at all given this project's
hard-won history with function timeouts.

**How it affects scoring:** two mechanisms, both gentle by design.
Documented grounds relevant to the selected species apply a per-cell bonus
(up to +25%) that fades smoothly with distance — never a hard cutoff, and
being far from a known spot never zeroes a location out, since plenty of
fish are caught away from the famous spots and the forecast shouldn't
just keep pointing at the same six places. The seasonal calendar applies
as an area-wide multiplier (0.6x–1.1x) based on the current month and
target species — badly out-of-season dampens the whole forecast but never
silences it, and the narrative says so plainly rather than leaving a low
score unexplained. Both surface as their own source chips ("Local
grounds", "Season") and a note in the panel listing which documented
grounds actually influenced the result.

## Composite SST outage — diagnosed, not an app bug

Reported directly: Composite (ACSPO) SST stopped loading. Confirmed the
root cause before touching any code: the dataset itself is still live on
NOAA's server (`noaacwLEOACSPOSSTL3SnrtCDaily`, verified present in
ERDDAP's own current dataset listing), but that specific ERDDAP
installation's own status page
(cwcgom.aoml.noaa.gov/erddap/status.html) was reporting **"Currently, no
dataset is loading"** at the time, with several datasets failing in the
last load cycle. This is a genuine upstream NOAA outage, not a broken URL,
renamed dataset, or app bug — nothing in the app's own configuration was
wrong.

Improved anyway, since a transient outage doesn't mean nothing's
worth fixing: the tile-error banner's message used to say "try a
different date, or check your connection," which doesn't actually help
during a real server-side outage — no date will load if the server itself
isn't serving datasets. Composite (ACSPO) and MUR are hosted on two
completely independent NOAA servers (`cwcgom.aoml.noaa.gov` vs
`coastwatch.pfeg.noaa.gov`), so the banner now names the other source by
name as a concrete workaround when one specifically is failing, rather
than a generic suggestion that wouldn't help.

## Feature Intersection Score — the "secret sauce"

Direct request: reward how many major, largely-independent ocean features
overlap at a location, not just how good the blended average looks. The
geometric mean already requires factors to co-occur to some degree, but
it doesn't explicitly reward the *discrete* pattern experienced captains
actually look for — "how many different things are lining up right here,"
not "is the average decent." A temperature break, a chlorophyll edge, an
eddy signal, and strong current are four separate physical phenomena; a
cell where several overlap simultaneously is a materially different bet
than one that's merely decent everywhere.

Counts how many of those four are simultaneously "notable" (≥0.55, the
same bar the narrative's own strength buckets already use) at each
pelagic-species cell, and applies a bonus: 0-1 features, no bonus; 2,
1.1x; 3, 1.25x; 4 (every tracked feature at once), 1.45x — the "jackpot"
case named directly in the request. Bottom species are excluded; these
four are pelagic surface/convergence signals; snapper/grouper scoring
doesn't use any of them. Surfaces in both the narrative (3+ features gets
its own explicit sentence) and the factors breakdown (shown from 1
feature up, for full transparency even below the narrated threshold).

Tested directly against the scenario the idea specifically targets: two
cells with a similar geometric-mean core score, one with two strong
signals and two weak ones, the other with four moderate signals all
genuinely overlapping. Before this change they'd have scored similarly;
after, the four-overlapping cell scores meaningfully higher (0.846 vs
0.568 in the test case) — which is the actual point.

## Persistence and rate-of-change — "how long has it existed," not just "is it here today"

The other direct request, and probably the more significant one: a front
that's held its position for several days has had time for weed,
plankton, and bait to organize around it — a materially different,
better bet than an identical-looking front that just appeared. Likewise a
front that's visibly strengthening day over day is a real, actionable
signal on its own.

**Scoped to SST specifically** — the primary "front" variable, matching
how the idea was described (the worked example was a temperature front
specifically) — rather than attempting this for every source at once,
which would have meant a much larger, riskier change for a first pass.
Chlorophyll/eddy persistence would be a reasonable, separate follow-up
built the same way.

**How it works:** a second, parallel SST fetch requests a real ERDDAP time
*range* (confirmed, documented syntax — explicit ISO timestamps as the
start/stop of the time dimension, e.g.
`sea_surface_temperature[(2026-07-04):(2026-07-08)]` — not the "(last)"
single-frame request every other fetch here uses), covering a 4-day
window to robustly catch at least 3 distinct valid days even accounting
for a day's processing latency. The response is split into separate
per-day maps (a new function, `erddapToMapsByDay`, since every prior
fetch only ever requested one time step and never needed to look at the
time column at all) and each converted to the same point-array format as
everything else, for the same lookup performance.

For each grid cell: **persistence** counts how many of the available
prior days also showed a "notable" front (same ≥0.55 bar) at that exact
location — 0 prior days, no bonus; 1, a modest 1.06x; 2 (notable on every
available prior day — a front that's genuinely held for the whole
window), 1.12x. **Rate of change** compares today's break magnitude
against the oldest available day at the same spot — strengthening by
≥0.3°C gets a 1.12x bonus, weakening by the same margin gets a 0.95x
penalty, both only evaluated when there's a real signal today worth
trending in the first place. Both surface prominently in the narrative
(persistence gets language directly echoing "held its position... long
enough to organize," strengthening/weakening both get an honest,
specific call-out either direction) and in the factors breakdown.

**Performance, checked directly rather than assumed fine:** this
roughly quadruples SST-specific gradient lookups per cell (today plus up
to 3 historical days). Measured against the same realistic worst case as
the earlier performance fix (largest FIFR zone, fully dense data): 1.98s,
up from about 0.9s — a real but bounded increase, still under a quarter
of the function's 8,500ms total budget with the network fetch time not
even counted yet.

**A bug caught during testing, worth naming honestly:** the first version
of the test for this feature showed persistence and trend both reading as
if nothing had changed, which looked like it might be a real problem.
Traced it down before assuming that: the bug was in the *test's* own mock
URL parser, not in `forecast.js` — it was extracting the new fetch's date
range and mistaking it for the coordinate range, because the history
request has three bracketed dimensions (time, then lat, then lon) where
every other request in this app has only two (lat, lon), and the test's
regex naively grabbed the first two brackets it found instead of the
actual last two. Fixed the test, re-ran it, and confirmed the underlying
scoring logic was correct the whole time — but flagging this rather than
quietly fixing it, since "the test was wrong, not the code" is exactly
the kind of claim that deserves showing the work, not just asserting it.

## SST pixel-level compositing — hourly, then ACSPO, then MUR (server-side only, not displayed)

Direct report: Water Temperature and SST Break were "notoriously missing"
from the star ratings. Answering the diagnostic question behind that
directly, since it determines the whole design: this app distinguishes
**pixel-missing** (patchy nulls within an otherwise-successful fetch,
affecting individual cells) from **data-missing-entirely** (the whole
fetch fails, zeroing out `sources.sst` for the *entire* forecast — and
cascading further than it looks, since Persistence and Rate of Change are
computed from SST data too and disappear along with it). A consistent,
forecast-wide absence points at data-missing-entirely, which matches a
concrete, confirmed finding elsewhere in this project: this forecast's
SST fetch and the composite map layer hit the identical NOAA server and
dataset, and that server had a real outage.

**This section supersedes an earlier, simpler version of this fix** built
in direct response to that finding — a whole-tier fallback (accept an
entire source if it had any usable pixel, otherwise move to the next
source entirely). Superseded by a more precise specification: rather than
accepting or rejecting a whole source as one unit, individual missing
*pixels* get backfilled directly, one at a time, from progressively older
data, stopping as soon as coverage is good enough rather than requiring a
perfect single source.

**Exactly as specified**: start with the latest hourly (GOES-19) SST.
Walk back hour by hour, up to 72 hours, filling in whatever pixels are
still missing with the most recent value available for each — not
overwriting a pixel that's already filled with an older one, since more
recent is always preferred. Stop as soon as at least 90% of the forecast
area has data. If hourly alone can't reach 90% within that 72-hour
window, continue the same backfill through ACSPO, day by day, for up to 5
days. If still short, continue through MUR the same way, also up to 5
days. Whatever's still missing after all three is left null — an honest
gap, not a fabricated value.

**"90% of the forecast area" means the actual scoring grid**, not an
abstract notion of area — coverage is checked against the exact same
`GRID_N` × `GRID_N` cell centers (~324 of them) the scoring loop itself
uses, using the exact same coordinate formula, so this is measuring the
real thing the forecast depends on, not a proxy for it.

**Made feasible by fetching each tier's entire lookback window in one
network call, not one call per hour/day.** The specification describes 72
+ 5 + 5 = 82 conceptual steps; done as 82 separate fetches, that's not
feasible inside this function's time budget. Instead, each tier's whole
window is fetched once (a real, confirmed ERDDAP capability: an explicit
time range returns every distinct frame within it, not just the newest),
and the hour-by-hour/day-by-day backfill happens entirely in memory
against that one response — at most 3 network round-trips total, however
many individual hours or days actually get walked through.

**Coverage-checking is incremental, not recomputed from scratch after
every frame.** A cell that's already covered is never re-checked — once a
point is within range of a cell, adding more points elsewhere can't
un-cover it, so this is safe, not just faster. This is what keeps the
absolute worst case (all 72 hourly frames, all 5 ACSPO days, all 5 MUR
days, never actually reaching 90%) cheap: measured directly at 4ms of
in-memory work for that exact scenario, confirming the real cost of this
design is the (at most 3) network fetches, not the compositing logic
itself. Confirmed end-to-end through the actual handler too, not just the
isolated function: the realistic worst case (largest FIFR zone, every
tier exhausted, dense payloads throughout) completes in ~2–3.5s, well
inside the 8,500ms budget.

**A bug found while testing, worth naming honestly:** partway through
verifying this, a test scenario designed to simulate hourly and ACSPO
both failing showed neither failure logged at all — a gap that led
directly to a real fix in the production code, not just the test. Tracing
it: a tier whose fetch succeeds at the HTTP level but returns a genuinely
empty table (zero rows) wasn't being logged as anything, silently
distinct from both "contributed some pixels" and "failed to fetch."
Fixed by logging that case explicitly (`"hourly:ok-but-zero-frames"`,
distinct from `"hourly:fetch-failed"`) so the diagnostic trail is complete
regardless of which of the two different ways a tier can fail to
contribute. Separately, the *test's own mock* also had a bug once this
was traced further — it simulated an HTTP failure by returning it from
inside the mocked `.json()` method rather than from the fetch result
itself, which doesn't actually trigger the real code's `res.ok` check.
Both are named specifically, not glossed over, since "found a bug in
production code while chasing what turned out to be a separate bug in the
test" is exactly the kind of thing worth showing, not just asserting was
handled.

**Verified against multiple scenarios, not just the happy path**: a
single hourly frame with full coverage (stops immediately, 1 fetch); a
sequence of hourly frames where coverage only crosses 90% partway through
the 72-hour window (stops exactly there, confirmed via the actual
frame-by-frame log, not just the final result); hourly exhausted
entirely, correctly escalating to ACSPO; both exhausted, correctly
escalating to MUR; all three failing outright; and — the specification's
central claim, checked directly rather than assumed — a scenario where
all three sources contribute *different, non-overlapping* pixels, with
the final composite confirmed to be the union of all three, not just
whichever tier was tried last.

**Server-side only, not displayed in the app** (direct scope
clarification) — `index.html` is completely unchanged by this. The
response still carries diagnostic fields for verifiability without any
UI exposure, same principle as everywhere else in this app:
`sources.sstCoverage` (the final fraction of scoring cells covered),
`sources.sstReachedTarget` (whether backfilling actually hit 90%), and
`sources.sstLog` (the complete frame-by-frame trail — which hours/days
from which source contributed how many pixels and what the running
coverage was after each).

**Scope note**: this pixel-level compositing applies to the primary
("current conditions") SST fetch specifically. The separate multi-day
history fetch that Persistence and Rate of Change depend on is
deliberately unaffected, keeping its own simpler ACSPO-then-MUR whole-tier
fallback — that feature needs to compare *distinct* prior days against
each other, which a multi-source, multi-hour composite for each of those
days would blur rather than help.

## Unstrided native-resolution queries — a real gap found from a second report

Reported again, after the pixel-compositing fix above: several inputs
still missing. Worth being direct about what this meant — the compositing
*logic* had been thoroughly tested, but only ever against mocks written
for this project, never against the real dataset's actual behavior, since
this sandbox has no live network access to verify against. That gap
between "tested" and "verified against reality" is exactly what this
report exposed.

Checked the actual live dataset metadata for `goes19SSThourly` directly
rather than continuing to guess — its `_ChunkSizes` attributes show
roughly 6000 × 5900 points across its full extent, working out to about
0.02 degrees per pixel: real high-resolution satellite data. Every
gridded query in this file, not just the new compositing ones, had been
requesting that full native resolution with no stride at all. For a
realistic bbox across up to 72 hourly frames (or 5 days for the
composites), that's a potentially enormous single response — plausibly
enough to time out or hit ERDDAP's own documented size limits (confirmed
in ERDDAP's own client documentation: oversized requests return an HTTP
500 with guidance to "reduce the amount of data...via space, time, or
variables"). That would explain the exact symptom reported far better
than a genuine data-availability gap would: a consistent, repeated
absence rather than an occasional one.

**Fixed by striding every gridded query in this file** — not just the SST
ones — down to roughly the resolution the ~324-cell scoring grid actually
needs (about 40 points per axis; `downsampleMap`'s own existing cap),
using ERDDAP's documented `[(start):stride:(stop)]` syntax. The stride
assumes a deliberately conservative (dense) ~0.01-degree resolution — MUR
data's well-documented ~1km native grid, the densest of the sources used
here — so it's never too small even for the densest case; requesting
somewhat more resolution than strictly necessary from a coarser source is
a far safer error than under-striding a dense one and reintroducing the
same problem. Checked directly across the full range of real bbox sizes
this app actually uses (smallest FIFR zone to largest): stride
consistently keeps each query to roughly 20–40 points per axis regardless
of the underlying region's size, and the constructed query URLs were
checked character-for-character against ERDDAP's own documented stride
syntax before trusting them.

**Named honestly, not left implicit: this can't be fully verified from
here.** Every fix in this project up to this point has been checked
against mocks, which can validate logic but can't confirm real-world
payload sizes, timeouts, or how a live ERDDAP server actually responds
under load — this sandbox has no live network access to those specific
NOAA endpoints. What's been verified directly: the query URLs are
syntactically correct against ERDDAP's own documentation, the stride
values land in a sensible range for every realistic bbox size in this
app, and the full existing test suite — SST resilience, FIFR zones,
persistence, distance-cutoff, worst-case performance — still passes with
striding in place. Whether this fully resolves what was reported is
something only a real run against production traffic can confirm.

## Cumulative sequential-fetch timing — found by testing with real delays for the first time

Reported a third time: still not all inputs showing, even after the
striding fix above. That pushed past continuing to guess at external
causes and into re-reading the SST resilience code end to end, hunting
for an actual bug rather than another server-side explanation.

**Found by hand-computing the worst case, not by testing**: `buildCompositeSst`
is sequential internally — hourly awaited, then ACSPO, then MUR. With the
per-tier timeouts at the time (6000ms/5000ms/5000ms), a case where each
tier takes close to its full timeout before failing adds up to roughly
6000+2500+300 ≈ 8800ms for that one chain alone — already past this
function's own 8,500ms budget, before the scoring loop that runs after it
resolves gets any guaranteed time, and plausibly past the hosting
platform's own execution limit. If the platform kills the function
outright, the result isn't a graceful partial response — it's however the
client happens to handle a request that never came back. That's a very
plausible match for a *repeated* "still missing" report. Worse: every
earlier resilience improvement made this more likely to trigger, not
less — more fallback tiers means more potential sequential latency,
backwards from the intent each time.

**The actual root cause of every mock-based test missing this**: every
performance test up to this point mocked `fetch()` to resolve instantly.
That validates logic — it cannot validate cumulative timing, because
there's no timing to measure. This was a real, structural gap in how this
project had been testing itself, not a one-off oversight.

**First fix attempt — a shared, depleting time budget across all three
tiers — was itself tested with actual simulated network delays** (not
instant resolution, specifically to close the gap above) and directly
caught a second, real problem: if hourly and ACSPO were both slow before
failing, they could exhaust the shared pool entirely, and MUR — the most
independent, most likely-to-succeed fallback, on a completely different
server — never got attempted at all, even in a scenario built so that it
would have worked. That's an excellent match for the reported symptom:
not every source down, just the one most likely to help never getting
its turn.

**Fixed properly with independent, fixed timeouts per tier** rather than
a shared pool — every tier gets its own full allotment regardless of what
happened before it, so a slow-but-failing earlier attempt can never crowd
out MUR's chance. Rebalancing came from testing, not just theory: an
initial set of tighter caps was tested against a "slow but genuinely
working" 1.8-second response and failed it too — solving the timeout risk
by creating a new one, killing real, eventually-successful data. Retuned
so MUR specifically gets the most generous allotment of the three (the
one this whole design most needs to succeed), while the sum across all
tiers (6,500ms worst case for the primary chain) still reserves guaranteed
time afterward. The same shared-pool problem existed in the separate
history fetch persistence relies on too, and got the identical fix.

**Verified against both edges directly, not just the happy path**: a
slow-but-working 1.8s response now succeeds (confirmed via the actual
`sstLog`, not just a pass/fail assertion) where it previously would have
been aborted; a genuinely hung 8-second server still resolves the whole
request in about 6.5 seconds, comfortably inside budget rather than
risking a platform-level kill.

## Wind (and pressure/tide) forced to wait for the SST chain — an unnecessary dependency, not a real one

Reported a fourth time, this time with the exact list of which 8 of 14
inputs were actually showing. That specific list mattered — comparing it
against the full 14 directly (not re-guessing) showed the gap was Water
Temperature, SST Break, Persistence, and Rate of Change (all one root
cause: the SST chain), plus, distinctly, Chlorophyll and Wind. Two
genuinely separate failures in the same report, not one.

**Wind traced to a real, previously-unnoticed structural bug**: wind,
tide, and pressure's own multi-step chain (a second round of fetches
depending on the first, then a third depending on the second) was
grouped inside the *same* `Promise.all()` as the SST chain, chlorophyll,
altimetry, currents, and bathymetry — even though it doesn't use any of
that data. That grouping was never a real dependency, just how the code
happened to be organized. The practical effect: wind/tide/pressure's own
downstream rounds couldn't even start until the SST chain — by far the
slowest thing in that batch, especially once it grew a 3-tier resilience
chain — finished completely. Whatever time the SST chain used, wind's own
chain had correspondingly less, purely as a structural accident.

Pressure showing while Wind didn't is exactly what this predicts, not a
contradiction: both are attempted in the same constrained window, but
pressure's specific sub-fetch (a short list of nearby stations) is
lighter than wind's (a full hourly forecast) — under a squeezed shared
budget, the lighter one has better odds.

**Fixed by extracting the entire chain into its own function**
(`fetchWeatherTidePressureChain`) and making it one independent entry in
the main `Promise.all()`, rather than sequential logic bolted on after
that `Promise.all()` resolves. It now runs genuinely concurrently with
the SST chain and everything else, exactly as it always could have.

**Verified directly against the specific failure mode**, not just
generally: a test with the SST chain at its full worst-case duration
(every tier slow, ultimately empty) running alongside a fast, working
weather.gov response confirmed wind and pressure both succeed now — they
were never actually blocked by the SST chain being slow, only by an
unneeded structural dependency on it finishing first. A separate
everything-is-slow-simultaneously test confirmed the whole request still
resolves in about 6.2 seconds, safely inside budget.

**Chlorophyll's absence in that same report is still open, and said
honestly rather than folded into the fix above as if explained.**
Chlorophyll runs as its own independent entry in the very same
`Promise.all()` as the SST chain, with its own timeout computed
synchronously before any fetch begins — it was never structurally
downstream of anything else, so the mechanism found above doesn't reach
it. Ruled out as a plausible cause; not confirmed as the actual one.
The most likely honest explanation is genuine data unavailability for
that specific report's location and time — VIIRS, the sensor behind this
dataset, is optical and needs clear skies, unlike SST's hourly and MUR
tiers, which have some cloud-penetrating coverage. That's a real
possibility, not a certainty, and it's flagged as exactly that rather
than folded into this fix as if it were explained too.

## Wind fallback from station observations — a strong hypothesis, not a confirmed fix

Reported a fifth time, with the identical list of 8 inputs even after a
genuine redeploy — ruling out the previous, much simpler explanation
(stale deployment) and confirming this needed to be treated as real. One
detail pointed somewhere new: Wind has failed on *every single report*
while Pressure has succeeded on every one, even after the concurrency fix
that put them on genuinely equal footing. A race condition wouldn't
produce that — a race would vary. A structural difference between the two
underlying data sources would.

**Checked directly rather than assumed**: NWS's own API documentation
confirms coverage is United States only, with a 404 possible entirely
outside it. More specifically, `forecastHourly` (wind's source) and
`observationStations` (pressure's source) are genuinely different
systems — one is a gridded product generated per Weather Forecast Office,
fundamentally a land-forecasting tool; the other is a list of physical
station locations, which includes NDBC buoys placed specifically
offshore. A point far enough out to fish for pelagics could plausibly get
a valid grid mapping with no meaningful hourly forecast data, while still
having a real, working buoy nearby. That would produce exactly this
pattern — not a bug in this app's fetch logic at all, an external
coverage boundary.

This is a strong, evidence-based hypothesis, not a confirmed diagnosis —
said directly rather than implied. A live query against the exact
coordinates in question would confirm or rule it out with certainty; that
level of proof isn't available from here.

**What was actually built, regardless of whether the hypothesis is
exactly right**: wind now has a second, independent source. If
`forecastHourly` doesn't produce usable data, wind speed is pulled from
the same station observations already being fetched successfully for
pressure — physical instruments, not the gridded forecast system, so they
don't share its limitation. This uses data already in hand rather than
issuing an extra fetch, and only activates when the primary path didn't
already succeed, verified directly: a test with a working `forecastHourly`
response confirms the fallback stays out of the way, and a separate test
matching the hypothesized failure mode (empty gridded periods, a working
buoy observation with a real wind reading) confirms wind now recovers via
the fallback. This is a real improvement on its own merits — two
independent sources beats one regardless of what's actually happening at
any specific location — even if it doesn't turn out to be the whole
explanation.

**Chlorophyll remains genuinely open.** Nothing in this investigation
reached it — it's an independent fetch with its own timeout, structurally
unconnected to weather.gov entirely. If Wind now recovers and Chlorophyll
still doesn't, that's real signal: it would mean the location itself, not
a shared mechanism, and the next step would be checking actual recent
satellite coverage for that specific place and time rather than guessing
at another code path.

## The actual root cause — downsampling assumed a regular grid, which stopped being true the moment compositing began

Found from one precise, specific detail in a sixth report: SST Break
worked *before* the pixel-compositing request, and never again after —
not "still broken," a specific before/after boundary. That's a
fundamentally different, much more useful kind of clue than "still
missing" was, and it pointed away from every external explanation
(server outages, payload size, timing) and straight at something in the
compositing code itself.

**The bug**: `downsampleMap`, used everywhere in this app to keep large
responses to a manageable size, keeps a set of lat values and a set of
lon values *independently*, then keeps a point only if both its exact lat
and its exact lon individually survived their own separate selection.
That's correct for a genuinely regular, rectangular grid — true for every
other source here, since each is one query against one dataset's own
native grid, where every kept lat really does pair with every kept lon in
the real data. It was never true for the SST composite once pixel-level
compositing existed, because that composite can be the union of up to
three different sources' grids — hourly, ACSPO, and MUR don't share a
coordinate lattice, each has its own native resolution and offset. On a
merged, misaligned scatter like that, a given point's specific (lat, lon)
pair is essentially unique, so requiring both coordinates to independently
survive two unrelated selections discards most of the data — real,
successfully-composited data, thrown away one step later by a function
whose core assumption had quietly stopped holding.

**Confirmed directly before touching any code, not just reasoned about**:
a realistic 3-source composite (each source already at this app's own
40-point-per-axis server-side stride target) retained only 24.9% of its
points through `downsampleMap`, against 100% for a single-source grid of
the identical size. That ratio isn't fixed — it depends on exactly how
the real sources happen to align — which means it could plausibly have
been far worse for some actual requests, particularly worth naming since
it's a likely part of why this looked so consistent across every report:
different specific locations could land anywhere on that spectrum, but
none of them were ever safe.

**Fixed with a second, composite-safe function** (`capPointArray`) used
specifically for the SST composite — simple, order-based decimation on
the point array directly, keeping every Nth point regardless of the
spatial arrangement, with no grid-regularity assumption to break.
`downsampleMap` itself is untouched and still used everywhere it's
genuinely correct — chlorophyll, altimetry, currents, bathymetry, and
each individual day in the separate persistence history fetch (which
pulls from one source at a time, never a merge, so the regularity
assumption still holds there).

**Verified end-to-end against the exact failure shape**, not just the
downsampling function in isolation: a mock with hourly covering part of
the area and ACSPO — on a deliberately different native grid, offset from
hourly's — filling the rest. `sources.sstCoverage` (measured by
`buildCompositeSst` itself, before the buggy step) already showed 100%,
confirming the compositing logic was always sound; the finished response
now correctly carries Water Temperature and SST Break through instead of
losing them one step later. Full existing regression suite — FIFR zones,
distance-cutoff, persistence, the SST outage scenario, wind's fallback,
worst-case timing — still passes.

## A payload-size hypothesis for the multi-day queries specifically — and real diagnostic gaps closed either way

Reported a seventh time. Wind was confirmed working by this point, which
narrowed things usefully: the remaining gap was Water Temperature, SST
Break, Persistence, Rate of Change, and Chlorophyll — and critically,
Altimetry, Currents, and Structure were all still fine, including
Structure, which lives on the exact same server as MUR. That specifically
rules out a server-wide outage as the explanation this time; something
else has to be different about the failing sources specifically.

**Checked for a sibling of the previous bug first**, since that was the
highest-value thing to verify before writing any new code: audited every
remaining call to the function responsible for the last fix, specifically
looking for another place multi-source data might get merged before
downsampling. None exists — every other call site, including the
persistence history path, is confirmed genuinely single-source. That bug
class is fully closed, not just fixed in the one place it was found.

**What's actually different about the four still-missing SST-family
inputs**: they're the only sources using the multi-day time-RANGE ERDDAP
queries (hourly's 72-hour window, ACSPO/MUR's 5-day windows) — every
currently-working source uses a single-time-step query instead.
Chlorophyll doesn't fit this specific pattern (it's single-time-step
too), so it's named as a separate, still-open question, not folded into
this explanation.

**The hypothesis, stated as a hypothesis, not a confirmed diagnosis**:
even after striding the spatial dimensions, hourly's 72-hour range can
still span up to 36 distinct time steps (after this round's additional
2-hour time-stride) — a meaningfully larger payload than any single-
time-step query, and the timeout budget for it may simply not have been
generous enough for a payload that size to reliably transfer, not a sign
of anything wrong with the query or the data itself.

**Two concrete changes made regardless of whether that hypothesis turns
out to be the whole story**: hourly's time dimension now also uses a
stride (every 2 hours instead of every hour) to reduce that specific
payload, and its timeout was raised accordingly, rebalanced against the
other two tiers to keep the same total ceiling this project has
maintained since the timing bug was first found — verified directly:
even with every SST-family fetch deliberately exceeding its new, larger
cap, the whole request still resolves in well under 7 seconds.

**The change most likely to actually matter next time, regardless of
whether this specific fix is right**: every failure in this chain now
records *why*, not just *that*. Both the primary composite and the
separate history fetch (which had no failure logging at all before this)
now capture the real reason — an HTTP status code or the specific error,
distinguishing a timeout from a server error from anything else — in
`sources.sstLog` and the new `sources.sstHistoryLog`. If this round's
specific fix doesn't fully resolve it, the next report won't require
another multi-step investigation to narrow down — the actual reason will
already be sitting in the response.

## Chlorophyll over-strided into near-emptiness — its native grid is ~4x coarser than SST

The one input missing in every single report that no prior fix ever
touched. Chased it specifically by comparing the app's *working*
chlorophyll map layer against the forecast's fetch of the same dataset —
a useful before/after within the app itself, since one works and one
apparently never has. Query structure turned out to match (same dimension
order, same dummy altitude axis handled correctly in both), which ruled
out the obvious candidate.

**The actual difference, confirmed from the dataset's own metadata**:
this VIIRS chlorophyll product has a native resolution of ~0.0375° —
roughly four times coarser than the ~0.01° dense SST data the striding
logic was originally tuned for. The stride helper assumed the dense
value, so applied to chlorophyll it over-strided badly: for a typical
FIFR zone it requested only about 10 of the ~39 actually-available native
points per axis (every fourth point from an already-sparse grid). In a
partly-cloudy scene — routine for an optical sensor — dropping ~75% of an
already-coarse grid could easily leave zero valid pixels anywhere near
the small scoring area, which is a strong, concrete candidate for why
chlorophyll specifically has been the most persistently-missing input of
all.

**Fixed** by computing chlorophyll's stride against its own real native
resolution instead of the SST-tuned default, restoring roughly the same
target point density every other source gets (all ~39 available points
per axis for that same zone, instead of 10). Quantified directly before
and after, not just adjusted by feel.

**Honest about the limit of this one**: unlike the downsampling bug — a
provable logic error with a provable fix — this is a real, measured
improvement that makes chlorophyll *far* more likely to return usable
data, but can't be a guarantee, because an optical sensor genuinely has
no data to give through heavy cloud cover regardless of how the query is
strided. If chlorophyll still comes back missing for a specific location
after this, the new `sources` diagnostics distinguish the two cases
directly: an empty-but-successful fetch (real cloud cover, nothing more to
do) versus a failure (something still worth chasing). Either way, this
removes a genuine, quantified defect that was making the problem
considerably worse than raw data availability alone ever would have.

## Feature Intersection precisely defined, and a depth floor added for the actual intent

Two direct questions worth answering exactly, since imprecise answers here
have caused real problems before: how is Feature Intersection defined, and
is there a search radius involved?

**There is no intersection radius.** Read directly from the code, not from
memory: SST break, chlorophyll edge, eddy, and current are each scored
independently at a given cell, using that cell's own nearest-neighbor
lookup within that SOURCE's own distance tolerance (`sstMaxDistMi`,
`chlMaxDistMi`, `sshMaxDistMi`, `uMaxDistMi`/`vMaxDistMi` — each derived
from that source's own data density via `estimateSpacingMi`). "Intersection"
means exactly this: at one cell, how many of those four independently-
computed scores individually clear a 0.55 threshold. `{0:1.0, 1:1.0,
2:1.1, 3:1.25, 4:1.45}` is the resulting bonus. There's no separate radius
tying the four together — their co-location is just that they're all
evaluated at the same `(lat, lon)`, each through its own lookup.

**That answer explains the shore problem directly**: with no concept of
"how far offshore," Feature Intersection is exactly as willing to reward
four nearshore artifacts lining up as four genuine Gulf Stream signals.
Clarified intent made the actual bug visible: this is meant to find the
Gulf Stream edge, and the existing land mask only ever excluded literal
land — a cell in fifteen feet of water a quarter-mile off the beach was
still fully eligible for every score, including Feature Intersection's
bonus.

**Fixed with a minimum-depth floor for pelagic scoring**, applied right
alongside the land mask and using the same already-fetched bathymetry —
cells shallower than `MIN_PELAGIC_DEPTH_M` (37m, ~120ft, a starting
default) are excluded before scoring, the same way land cells are.
Explicitly gated to non-bottom species only: reef and shelf structure is
exactly where snapper/grouper scoring is supposed to look, so the floor
would be actively wrong to apply there, and the response's
`shallowCellsExcluded` count is 0 for bottom species by construction —
verified directly, not just asserted, that the floor genuinely never fires
for them.

Verified against a three-zone scenario built specifically to distinguish
"is this cell disqualified because it's land" from "is this cell
disqualified because it's shallow ocean": land, then a real but shallow
nearshore shelf, then genuine deep water past a shelf edge. Pelagic
scoring correctly surfaced only deep-water spots; the shallow-exclusion
counter confirmed zero exclusions for a bottom species run against the
identical geometry.

**120 feet is a starting point, not a measured fact** — the Gulf Stream's
inner edge varies enormously by location (it can run within a few miles of
shore off Palm Beach County, much farther out elsewhere), and this single
constant can't capture that regional variation. It's one clearly-labeled
number in the code, easy to retune per report if it's excluding real edge
structure or letting too much nearshore water through.

## Neighborhood convergence — scoring restructured around "nearby," not "exactly coincident"

Direct architectural feedback, and a real, correctly-identified gap: the
scoring required a temperature break, a chlorophyll edge, an eddy, and
current to each independently register as strong AT THE EXACT SAME GRID
CELL before Feature Intersection's bonus applied. Confirmed precisely in
the prior response, not assumed: each of the four signals used its own
independent nearest-neighbor lookup, evaluated at one single point.
Oceanographically that's often not how these features actually sit
relative to each other — a thermal front, an eddy's sea-surface-height
signature, a chlorophyll edge, and a current convergence can all be part
of the same real, fishable area without their individual peaks landing on
the identical pixel. The scoring had no way to credit that.

**Restructured into two passes.** Pass 1 computes every signal exactly as
before, at each cell's own exact location — no behavior change yet. Pass 2
is the actual mechanism change: for pelagic species, each of the four
convergence signals named in the request (SST break, chlorophyll edge,
eddy, current) becomes the BEST occurrence found within a search radius of
that cell, not just its own value. Because Feature Intersection's
"notable" check and the core geometric-mean score both consume these same
now-neighborhood-aware numbers, the convergence property propagates
automatically through the whole scoring formula — not just a discrete
bonus layered on top, but genuinely "how good is this area," which is
what was actually asked for.

**Two things deliberately excluded from this treatment**: species
temperature preference and bottom structure. Neither was in the four
signals named in the request, and both are conceptually about actual
local conditions — is the water HERE the right temperature, is there a
ledge HERE — not proximity to a feature located somewhere else. Persistence
and rate-of-change were also deliberately kept point-exact, for a related
but distinct reason: they're specifically about whether THIS front, at
THIS location, has held its position over multiple days, which has to be
about this cell's own history, not a neighborhood search over today's
snapshot.

**Detail numbers travel with their score**, not left mismatched: when a
nearby cell's break supplies the winning score, its actual °F/knots/etc.
values travel with it too, so a displayed number always describes the
specific reading that produced the displayed score — never a
convergence-boosted score paired with a merely-local, unrelated detail
figure.

**5 miles is the starting search radius** — a defensible but not
measured choice, the same honest caveat as the depth floor: easy to
retune in one place if it's drawing in features that are really too far
apart to fish as one area, or missing genuine convergence just outside
the boundary.

**Verified against the specific failure the old design had**, not just in
the abstract: four sharp, non-overlapping signal zones placed a mile or two
apart, deliberately never coincident at any single point. Under the old
point-exact logic, no cell could ever have scored 4/4 in this layout — it
was structurally impossible. Confirmed directly, not assumed: a cell near
the center of the cluster now correctly registers all four signals and
receives the full 1.45x "jackpot" bonus. The full existing regression
suite — FIFR zones, the land mask, the depth floor, SST resilience,
persistence — still passes, and the added O(N²) neighborhood search (at
most ~105,000 distance checks per request) added no measurable cost to
overall response time.

## Feature Intersection's radius was a hard cutoff — now scales continuously with distance

Direct question, answered precisely rather than from memory: yes, there
was a radius (5 miles) — but it was a hard cutoff, not a distance scale.
A signal 0.1 miles away and one 4.9 miles away counted identically (both
just "within radius, take the max"), and anything past 5 miles counted as
exactly zero. The follow-up request — scale by proximity, decreasing as
distance increases — was a real gap in that design, not already covered
by the radius alone.

**Fixed with linear distance decay**, applied at the same neighborhood
search used for the four convergence signals: full strength at a cell's
own location, scaling straight down to zero exactly at the 5-mile
boundary. Chosen for being the most literal, easiest-to-verify match for
"scale based on how close... and decrease as they get further away" —
`decayFactor(0) = 1`, `decayFactor(radius) = 0`, linear in between, with
no hidden curve to second-guess. Extended to persistence's historical
search too, for consistency — it shares the exact same loop, and it would
have been a strange inconsistency for today's four signals to decay with
distance while yesterday's front didn't.

**A real bug found and fixed while wiring this in, not left implicit**:
initially, the historical "notable" check correctly used the new decayed
value, but the day-to-day trend comparison still measured against
today's raw, undecayed magnitude — comparing a decayed number to a raw
one would have produced a misleading "weakening" trend that was really
just distance decay, not an actual physical change in the front. Fixed by
tracking two parallel values for each historical day: the decayed one
decides which nearby occurrence is most relevant (combining strength and
proximity, same as the four signals), and a second, raw value from that
SAME winning occurrence feeds the trend delta, so "how many degrees did
this front actually change" stays a real, physical number.

**Verified two ways**: the exact decay formula extracted and checked in
isolation against the actual line in `forecast.js` — confirmed full
strength at zero distance, exactly zero at the boundary, and a
moderate-strength signal crossing below the notable threshold between 1
and 2 miles out, a smooth transition rather than a cliff. And through the
full handler: the neighborhood-convergence and persistence-as-neighbor
tests from prior rounds both still pass with decay in place, including a
direct check that the trend fix produces a correct "strengthening" result
rather than a decay-induced false "weakening."

## Wind as Ekman transport — a new upwelling signal, physics verified before trusting it

Direct request: use wind as Ekman transport to capture upwelling, sourced
from NOAA NCEI Blended Seawinds. This is a genuine, separate addition, not
a replacement of the existing wind-comfort scoring (which stays exactly
as it was — "is the wind calm enough to fish in" is a different, still
useful question from "is this water being enriched by wind-driven
upwelling"). Both now exist side by side.

**The dataset**: confirmed directly from live metadata, not guessed —
`noaacwBlendedWindsDaily` on the coastwatch.noaa.gov ERDDAP server, u_wind
and v_wind at 10m, 0.25° resolution (much coarser than any other source
here, so it gets its own stride computation, same principle as
chlorophyll's). One real gotcha caught before it could cause a silent
failure: this dataset uses 0-360° longitude, not the -180/180 convention
every other source here uses — confirmed from `Westernmost_Easting: 0.0`,
`Easternmost_Easting: 359.75` in its own metadata. Handled by converting
this app's longitude to 0-360 for the query, then converting the
response's points straight back to -180/180 immediately after parsing —
without that second conversion, `erddapToMap` would have built its point
keys directly from the 0-360 values returned, and every later lookup
(which all assume -180/180) would have silently matched nothing at all.

**The physics**: wind pushes surface water not downwind but roughly
perpendicular to it (Coriolis effect — 90° right in the Northern
Hemisphere). Where that transport diverges — spreads out faster than it
flows in — the surface water has to be replaced from below: cold,
nutrient-rich water rises. That's upwelling, one of the most reliable
drivers of biological productivity in the ocean. Built from three
components: a standard bulk wind-stress formula (Large & Pond, 1981),
Ekman transport from that stress and the Coriolis parameter, then the
divergence of the transport field across a cell — the same 4-neighbor
finite-difference structure as the SST/current break signals, applied to
a genuine vector divergence this time rather than a gradient or shear
magnitude.

**A real sign error was caught before this ever reached the code.** An
early derivation had the final upwelling/downwelling sign backwards —
plausible-looking algebra, wrong result. Caught specifically because the
formula was checked against three independent, real, documented physical
cases rather than trusted on derivation alone: a cyclonic (counterclockwise)
wind pattern, explicitly documented to cause upwelling in the Northern
Hemisphere, initially came out negative under the flawed version.
Re-deriving from mass conservation directly — transport diverging out of
a column must be replaced from below, by definition — fixed it, and the
correction was then independently confirmed against two more cases: a
documented wind-jet divergence example, and a clockwise-wind negative
control that correctly showed downwelling. All three had to agree before
this was trusted.

**Normalized against a real citation, not a guessed range**: Wikipedia's
upwelling article states wind-driven upwelling "normally... occurs at a
rate of about 5-10 meters per day" — used directly as the anchor, so
+8m/day (strong upwelling) scores 1.0, 0 scores neutral 0.5, and -8m/day
(equally strong downwelling) scores 0.0.

**Point-exact, not neighborhood-aware** — like temperature preference and
chlorophyll favorability, this is about actual local conditions ("is this
specific spot being enriched right now"), not proximity to a feature
elsewhere, and it wasn't one of the four signals in the original
neighborhood-convergence request anyway. Integrated as a new 8% weight
across every pelagic species, with every other existing weight scaled
down by the same 0.92 factor to make room — preserving each species'
relative balance exactly, verified directly that every total still sums
to 1.0.

**Verified end to end, not just in isolation**: a full-pipeline test using
a mock that deliberately returns wind data in the dataset's real 0-360
convention (not a shortcut back to -180/180) confirmed the conversion
actually works through the whole request, and that a cyclonic wind
pattern correctly scores higher than an otherwise-identical anticyclonic
one. Also added to `diag.js`, since this is a brand-new data source this
project has never queried live before — the same discipline as every
other source added here, given how much this project has learned about
not fully trusting an untested endpoint.

## Moon phase: a real, asymmetric daytime effect added alongside the existing tidal bonus

Direct request: near a full moon, daytime fishing for pelagics can suffer,
specifically because of moonlight, not just the same tidal-strength logic
already in place. Worth being precise about why this needed new code
rather than just retuning the existing moon bonus: the existing solunar
term is deliberately SYMMETRIC (new and full moon both credited equally,
since both produce the month's strongest tides) and has no concept of
time of day at all. What was described is neither — it's specific to full
moon (not new) and specific to daytime (not night), which needed a
genuinely separate, second term rather than an adjustment to the first.

**Grounded in real sourcing before writing any code**, given how specific
and asymmetric the claim was: a fisheries scientist quoted directly in
Sport Fishing Mag ("the daytime bite was best during the new moon" versus
full-moon daytime being "poor to nonexistent"), and an independent
charter-log data point (~15% catch-rate swing concentrated within 3 days
of full/new) used to calibrate how sharply the effect should taper with
distance from the exact full moon, rather than guessing at a shape.

**Two new pieces, each verified in isolation before being trusted,
matching this project's usual practice for anything physically/
astronomically real** (the same discipline used for the Ekman transport
work earlier): a solar elevation calculation (the standard NOAA solar
position algorithm) checked against known reference facts — Miami's
summer-solstice noon sun angle, winter-solstice noon angle, and a
local-midnight angle all landed within the expected ranges before this
was used for anything — and a full-moon-proximity measure, deliberately
asymmetric unlike the existing solunar term: it peaks exactly at full,
is exactly zero through the entire new-moon half of the cycle, and is
cubed for a sharper taper concentrated within a few days of full,
consistent with the cited charter-log window.

**The two combine into a real but bounded effect**: up to a 20% score
reduction at the extreme (exactly full moon, exactly solar noon), fading
to zero away from either condition — a full moon at night, or any other
moon phase at any hour, is completely unaffected by this new term. The
star rating itself now reflects the combined effect actually applied to
the score, with a specific "(daytime bite may be slow)" note shown only
when the effect is meaningfully engaged, not added as noise to the common
case where it isn't.

**A real bug in the test itself was caught before trusting the result** —
an early version tried to locate "solar noon" and "local midnight" by
adding fixed hour offsets to an already-arbitrary full-moon UTC timestamp,
which doesn't reliably land at either, since the exact full moon's own
time-of-day is unpredictable. That produced an exact day/night swap on
the first run. Fixed by directly searching for and verifying real
calendar dates that actually satisfy each condition, rather than assuming
the arithmetic. With that fixed, all four cases passed cleanly: full moon
at solar noon shows clearly reduced stars with the daytime note; the
same full moon at midnight, a new moon at noon, and a quarter moon all
show the term contributing exactly zero, confirmed directly rather than
assumed from the formula alone.

## The forecast button relocated entirely, rather than tuned again

Both reports named the same button — the forecast toggle overlapping the
chlorophyll/altimetry legend, and separately the true-color adjustment
button on top of it — which confirmed something more useful than either
report alone: it was specifically the forecast button doing the
colliding, in both cases, because it sat topmost in the right-side FAB
stack, reaching furthest up the screen of any of them. Whatever the
exact window height, that one button was always going to be the first to
reach whatever sits in the top-right corner.

Tuning the pixel spacing further would have "fixed" this only down to
some viewport height and failed again below it — the same shape of
problem as the attribution-banner fix two rounds ago, just recurring at
the other end of the same stack. So rather than another round of
spacing numbers, the forecast button moved off that stack entirely, to
the bottom-left corner instead. It can no longer collide with anything
in the top-right, regardless of window size, because it's no longer in
that column at all.

Positioned above the measure-tool's own label (which appears at the
bottom-left only while actively measuring) rather than overlapping it —
checked the label's actual height before picking the button's offset,
not assumed. The right-side stack is also one button shorter now, so its
own topmost button (Current arrows) reaches noticeably less far up the
screen than before, independent of the forecast button's move.

## Currents button icon: three converging arrows, based on the reference

Direct request, based on an uploaded reference: three wavy lines
converging to a single point and diverging upward into arrowheads,
inside a circle. Adapted fairly directly, since the reference was already
close to icon-scale simplicity, unlike the sailfish reference two rounds
back — same `currentColor` pattern as every other icon, same open-stroke
arrowhead style ("V" shape, not a filled triangle) the app's original
current-arrow icon already used, so the visual language stays consistent
with what was already there.

**Worth being honest about directly**: visual confirmation on this one
was less certain than the previous two icon rounds. The same rendering
pipeline (an actual headless Chromium already present in this
environment) was used the same way, but this round the tool didn't
return a result this session could visually confirm the way the sailfish
and contour icons were. Rather than claim a level of visual verification
that didn't actually happen, or hold up delivery indefinitely chasing it,
this was checked the ways that could still be genuinely verified:
confirmed the SVG syntax is valid, confirmed the render itself succeeds
and produces real (non-blank) pixel content rather than an empty or
broken image, and confirmed the drawn shape is symmetric left-to-right
and has the vertical structure a three-pronged converging arrow should
(a single convergence area low in the frame, three separate tips higher
up) — all checked numerically against the actual rendered pixels, not
assumed from the coordinates alone. That's real signal, but it's not the
same as having actually looked at it, and this is flagged directly rather
than presented as equivalent to the confirmation the last two icons got.

## Forecast button icon: leaping sailfish, simplified from the reference

Direct request, based on an uploaded reference badge (sailfish, waves,
clouds, a brain with sun-ray lines, all inside a circular emblem).

**A real, honest simplification, not the full reference shrunk down.**
The reference has five distinct visual elements at illustration scale;
this icon has to read clearly at 22px inside a 48px button, the same
real-world size as this app's other icons. Built and compared a few
combinations before choosing: the fish alone, the fish paired with a
small brain, and the fish paired with a simple wave line. The brain,
while thematically on point for an AI forecast feature, didn't survive
combined with a fish shape at this scale — two distinct recognizable
forms competing for the same dozen pixels reads as clutter, not as
"fish + brain." Clouds and the sun-ray lines around the brain were
dropped for the same reason before that comparison even started. What's
in the button now is the leaping sailfish itself — the reference's most
immediately recognizable shape — with a simple wave line beneath it
standing in for the water/motion context, refined over a couple of
passes to give the sail fin a clearer, more distinctly sailfish-shaped
silhouette rather than a generic fin.

Same `currentColor` pattern as every other icon in the app, so it
inherits the correct color in both the normal and selected button states
automatically.

## Forecast icon replaced again: the full badge this time, not the simplified version

Direct follow-up to the earlier sailfish icon, and a different brief this
time — include everything from the reference (brain, sun rays, both
clouds, the sailfish, layered waves), not the simplified fish-and-wave
mark built two rounds ago. That earlier simplification was a real,
reasoned tradeoff for legibility at 22px, but it was still a choice made
on this end; asked again with the full picture, the fuller version is
what's built now, without re-litigating that earlier call.

Every element from the reference is present as its own set of paths —
the brain's lobed outline with a center line and a few fold marks, five
short sun-ray ticks around it, two puffed cloud shapes, the sailfish
(reusing the refined body/sail/tail work from the earlier round), and
two rows of wave lines. Stroke width dropped from the app's usual 1.3-1.4
down to 0.7, since fitting this much detail into the same 22px space
needs proportionally finer lines to stay legible rather than fusing into
a solid mass. The outer circle boundary from the reference is gone, per
direct request — just the artwork itself, no frame, matching how the
sailfish-only version worked before it.

**The same visual-confirmation limitation as the currents icon last
round applies here too, and is flagged the same way rather than glossed
over.** The rendering pipeline itself worked correctly — real Chromium,
real screenshots of the actual button in the actual shipped file, zero
JS errors — but this session wasn't able to get a reliable direct look at
the pixels the way the sailfish and contour rounds could. Rather than
claim a level of visual confirmation that didn't happen, this was
checked the ways that could still be verified concretely: valid markup,
a genuinely non-blank render with content distributed across the full
vertical extent of the icon (not collapsed into one corner or missing
entirely), checked both in an isolated preview and, separately, on the
actual button cropped directly out of the real shipped file. That's real
evidence the geometry is sound, but it's not the same as having looked at
it — if the balance between the five elements needs adjusting once it's
actually visible, that's a fast, specific fix from here.

## Contours panel: dismissable by outside click, without turning contours off — and a real design tension resolved along the way

Three related requests, handled as one coherent change rather than three
separate patches, since two of them pull in opposite directions unless
reconciled deliberately.

**Outside click hides the panel without touching the on/off state.**
Straightforward on its own — a click anywhere outside the panel (and
outside the button itself) hides it, leaving contours exactly as they
were.

**That click doesn't also open the coordinate card underneath it.** The
map's own tap handler and this dismissal needed to be kept from firing
on the same click. Handled in the capture phase specifically — a
listener at the document level that runs and calls `stopPropagation()`
*before* the event ever reaches Leaflet's own click listener on the map
container, not after. A bubble-phase listener (the pattern this app's
other simple panels already use) would run too late to stop that; this
needed to intercept the click on the way in, not react to it on the way
out.

**The tension worth naming directly**: once an outside click can hide
the panel while contours stay on, there needed to be a way back to it —
otherwise adjusting opacity a second time would mean turning contours off
and back on just to see the slider again. Rather than leave that gap,
the button's click handling is now a genuine three-state cycle: off →
on (panel opens), on-with-panel-hidden → panel reopens (contours stay
untouched), on-with-panel-visible → off. A second click never
double-guesses which of those three states it's in; each was verified
directly; in order, on the same page, not assumed from the code alone.

**The NOAA attribution text in the panel is gone**, per direct request.
Left alone deliberately: the separate NOAA credit in the map's own tile
attribution control, which is a different string in a different part of
the app and likely required by the data provider's terms — not something
this request was about, and not removed without being asked.

## SST break narrowed to a 1-mile radius; wind removed as a scoring input

**A new, SST-specific radius, not a change to the shared one.** All six
signals previously shared one 5-mile neighborhood-decay radius. SST
break now has its own — 1 mile, distinct from the other five (chlorophyll
edge, eddy, current break, structure, upwelling), which are untouched at
5 miles. Implemented as two independent decay factors computed within
the same neighbor loop rather than a second loop, since the existing
5-mile check already bounds both correctly (nothing beyond 5 miles could
matter to either).

Extended, not left inconsistent: SST's persistence and rate-of-change
calculations — which compare today's break against prior days' readings
at nearby cells — now use the same 1-mile radius too, since they're
measuring the same underlying feature, not a separate signal with its
own idea of "nearby." This went a step beyond the literal request (which
named "the SST break" specifically), so it's worth being direct about:
if persistence was meant to stay at 5 miles, that's a one-line change to
revert.

Verified with a direct test, not inferred from the formula: a strong,
sharp SST front placed so one test cell sits ~0.5mi away (inside the new
radius) and another sits ~3mi away (inside the old radius, outside the
new one) — the near cell still scores the break strongly, the mid one no
longer does. An existing test that specifically checked a ~2.3mi drift
against the old 5-mile persistence radius needed rescaling to ~0.4mi to
match the new one — expected, not a regression, and confirmed passing at
the new scale.

**Wind's role as a scoring input is gone — the "Wind" star rating and
its contribution to the score — but a scoping decision here is worth
being explicit about.** The plain "Wind: X mph" text already shown in
the forecast panel is informational, not a star rating or scoring
factor, and wasn't part of what was asked to be removed, so it's kept.
Wind previously fed a blended `weatherScore` (40% wind, 60% pressure)
that drove a small area-wide score modulator; that modulator now runs on
pressure alone, unblended, rather than being deleted outright — pressure
trend is a real, independent, well-established signal in its own right,
not something that should have quietly gone down with wind. Confirmed
directly: a test with strong wind (35mph, well outside wind's old
"favorable" range) still produces a normal, pressure-driven score with
no "Wind" rating in the output, while "Pressure Trend" and the
informational wind text both come through untouched.

**One more thing worth naming so it's not confused with the removal
above**: this app also uses wind data completely separately, as a
gridded field feeding the Ekman-transport upwelling calculation — a
different data source, a different physical signal, powering one of the
seven core-weighted scores rather than the area modulator. That's
untouched. "Remove the wind input" reads as the point-forecast wind
score used for the Wind rating and area modulator, not upwelling's own
wind-driven physics, and the existing Ekman upwelling test still passes
unmodified, confirming that path was never touched.

## Persistence radius reverted to 5mi; persistence now requires the full feature intersection, not SST alone — and a real bug found and fixed along the way

**The radius, reverted as discussed.** SST break's own radius stays at
1mi, but persistence's neighbor search is back to the shared 5mi —
confirmed with the same realistic ~2.3mi drift scenario from the
diagnosis: correctly registers as 2 persistent days again.

**A substantially larger feature, not a small follow-up.** Direct
request: persistence now requires eddy, chlorophyll, and upwelling to
have ALSO been notable nearby on a given prior day — not just SST — for
that day to count. This meant three new multi-day historical fetches
(chlorophyll, SSH/eddy, wind u/v) alongside SST's existing one, each
against the exact same dataset already used for "today," just requesting
a date range instead of `(last)`.

**A real correctness problem, caught and solved before it could produce
silently wrong results.** These four sources are fetched independently —
different satellites, different processing latency — so their available
historical dates can genuinely differ. Matching them by array position
alone (day 0 from SST, day 0 from chlorophyll, etc.) risked comparing,
say, SST's Tuesday against chlorophyll's Monday without either signal or
the code ever knowing. Fixed by aligning all four to their actual
calendar dates before pass 1 ever runs — only dates present in *all
four* sources are used, computed once up front rather than re-derived
per cell.

**A second, genuine bug found while building this, unrelated to the
feature itself.** Wind history came back with `upwellingArr` reading
`[null, null]` no matter what — persistence for upwelling could never
register at all. Traced to a real gap: today's wind processing already
converts the data's native 0-360° longitude back to normal -180/180
range before use (`from360Lon`), but that conversion had never been
needed for history before, since SST/chlorophyll/eddy don't use 0-360
longitude — so it was simply missing from the new wind-history code.
Every distance check between a query point and the wind map was silently
comparing incompatible coordinate systems, always failing. Now applied to
history exactly as it already was to today's data.

**New notability thresholds for chlorophyll and eddy, since persistence
never had one for either before this round** — chlorophyll ≥0.174 mg/m³
gradient, eddy ≥0.0705m SSH gradient, both using the same 0.55 normalized
bar as SST's existing threshold and today's own Feature Intersection
check. Upwelling reuses today's exact scoring formula rather than
inventing a second one. These are reasonable starting points, not
empirically tuned — easy to adjust if real-world results suggest they
should move.

**Verified concretely, not assumed from the logic alone**: a scenario
where all four signals are genuinely notable at the same nearby location
on both prior days correctly produces `persistenceDays: 2`; the same
scenario with only chlorophyll's historical strength removed — SST,
eddy, and upwelling all still notable — correctly drops to `0`,
confirming the intersection requirement doesn't quietly fall back to
SST alone when the other three aren't behind it.

**Worth being direct about the tradeoff this creates**: persistence now
depends on five independent network fetches (SST, chlorophyll, SSH,
u-wind, v-wind history) all succeeding AND overlapping on shared calendar
dates, not just one. That's a meaningfully higher bar to clear than
before, on top of now requiring all four signals to individually clear
their own notability threshold on the same day. This is what was asked
for — genuine multi-signal persistence is a stronger, more meaningful
claim than SST alone ever was — but it will likely show up less often
than even the original SST-only version did, not more.

## Still not showing up — stopped guessing at structural fixes, added the ability to actually see what's failing

Two rounds of structural changes (merging requests, then decoupling
them) haven't resolved this. That's the honest signal to stop making
another guess in the same direction and instead get actual evidence,
since this sandbox has no live network access to the real data services
and can't observe their behavior directly — only reason about it.

**A real, concrete gap found**: every one of today's chlorophyll, SSH,
current, wind, and elevation fetches had zero failure-reason logging.
They either worked or silently fell back to empty, with no record of
which — no HTTP status, no timeout, nothing. Only the newer history
fetches had this. Added the same logging to all seven: `sources.chlTodayLog`,
`sources.sshTodayLog`, `sources.uCurrentLog`, `sources.vCurrentLog`,
`sources.uWindTodayLog`, `sources.vWindTodayLog`, `sources.bathyLog` — each
reads `"ok"` or a specific `"fetch-failed:httpNNN"` / `"fetch-failed:<reason>"`,
the same shape already used elsewhere in this file. The very next live
run will show, in fact rather than guesswork, whether chlorophyll's
fetch is genuinely failing and why, or whether something else entirely
is going on.

**Used the tools actually available to check what could be checked.**
Web search confirmed the chlorophyll dataset itself genuinely exists,
is reachable, and its real metadata matches what this code expects
(same variable name, same coordinate convention, recently maintained) —
direct evidence the external service isn't simply gone, not just an
assumption carried over from a comment.

**This project already has a purpose-built diagnostic tool for exactly
this situation** — `diag.js`, created after an earlier, unrelated round
of guessing that also didn't resolve anything, specifically to observe
real server behavior instead of hypothesizing about it. It already
probed chlorophyll and wind's simple, single-day query — and those
probes report OK. What it never tested is the actual new query shape
persistence introduced: a multi-day date *range*, not a single day.
Added that missing probe for chlorophyll, wind, and SSH (which had no
probe at all before now) using the exact date range `forecast.js`
itself computes. **This is the most direct way to get a real answer**:
opening `diag.js`'s own URL in a browser returns a fast, plain report of
exactly what each query actually does right now, including the specific
one that's never been checked before.

## Missing data now shown and annotated, not silently omitted

Direct request: every rating that depends on a data source — SST break,
chlorophyll, eddy/SSH, current break, structure, upwelling, persistence,
pressure trend — used to simply vanish from the list entirely when its
source had no data. That's honest in one sense (nothing false is being
shown) but easy to misread: an absent rating and a rating with a
genuinely poor score look identical from the outside, since both mean
"you don't see it listed as good."

Every one of these now always appears. When data is available it shows
its real score and detail as before. When it isn't, it shows the same
label with "No data available" in place of the star bar — deliberately
distinct styling (muted, italic text, no stars at all) so it can never
be mistaken for a real zero-star score, which is a very different claim
("this location is conditions" vs "this input couldn't be measured
here").

Local Grounds, Feature Intersection, and Moon Phase were already always
shown (their own scores are meaningful even at zero), so they're
unaffected other than gaining the same explicit noData:false field for
consistency, letting the client check one field uniformly rather than
needing to infer "has data" from a rating simply being present. Rate of
Change stays conditional on there being an actual SST trend to report —
that's a "doesn't apply here" case even when persistence itself has
working data (e.g. too weak a break to meaningfully trend), not a
missing-data case, so it's treated differently on purpose.

Verified two ways: confirmed a single failed source (chlorophyll) still
appears in the response, correctly annotated, while every real signal
around it displays normally; and confirmed a more realistic cascading
case — chlorophyll's history failing also makes persistence unavailable
(since persistence's calculation needs it) — correctly surfaces as "No
data available" there too, rather than that dependency being silently
lost. Checked the actual rendered HTML output as well, not just the
data going into it, to confirm the no-data state visually reads as
distinct from a real score.

## The shrinking box was the real symptom of a much bigger bug -- the server was analyzing roughly a quarter of the area it displayed

The observation about the box shrinking right after requesting was the
key that cracked this open, and it led to something more significant
than the percentile fix from last round.

**What was actually happening**: the client already computes the final,
intended forecast box before ever sending a request -- 50% of the
current map view's smaller dimension, capped at 50 miles. That
computed box IS what gets sent to the server. But the server was
independently re-running that exact same "50% of the smaller
dimension" calculation A SECOND TIME on top of it -- treating the
client's already-final, already-sized box as if it were a raw, unsized
map viewport that still needed its own shrink. The result: the server
was actually analyzing a box roughly half the side length -- a quarter
the geographic area -- of what the client displayed and the person saw
drawn on the map. This was invisible until the response came back and
the client synced the displayed box to match what the server had
actually analyzed, which is the exact "shrinking" that got reported.

**This also explains the persistent instability directly**, on top of
last round's percentile fix. If the real analyzed area was only ~20
miles on a side while the display showed ~40, a 1-2nm shift represents
a far larger proportion of the box that's actually being scored than it
looks like on screen -- the grid's own cell size shrinks right along
with the hidden, smaller area, making the whole thing more sensitive to
small changes than a person watching the displayed 40-mile box would
ever expect.

**Fixed by removing the duplicate shrink** -- the server now takes the
incoming box as the final, intended area (since the client already
sized it), keeping only the 50-mile maximum as a safety backstop for a
direct API call that might bypass the client and send an unbounded
request. The square-shape guarantee is unchanged.

Verified directly: a simulated ~40-mile client request now comes back
with the server's own analysisBounds matching ~40 miles, not silently
reduced to ~20. A deliberately oversized 120-mile request still
correctly caps at exactly 50 miles, confirming the safety backstop
itself wasn't accidentally removed along with the bug -- only the
duplicate shrink was.

## Wholesale spot changes from small location shifts — fixed with robust, percentile-based normalization

Six of the seven core signals (SST break, chlorophyll, eddy, current
break, structure, upwelling) score every cell relative to the min and
max found within the currently analyzed box, not against any fixed
threshold -- a deliberate choice so ratings reflect this specific area's
conditions, not a global scale. The cost: every cell's score depends on
whatever else happens to be in the box. An 18x18 grid over a 50-mile
area means each cell is roughly 2.8 miles wide, so a 1-2nm shift can
easily add or drop a handful of edge cells -- and if one of those is
unusually strong or weak, it can rescale everything else's score for
that signal, even though nothing about their own conditions changed.

Confirmed this in complete isolation before touching anything: one
cell, one real 0.5 degC gradient, completely unchanged data. With one
unrelated outlier cell included in the box, it scored 0.211. With that
exact same outlier excluded -- as an edge shift easily could -- the
identical cell scored 1.000. Since the final score multiplies six such
signals together, then greedily picks the top cell and excludes
everything near it before picking the next, even one signal reshuffling
near the top can cascade into a completely different set of spots.

Fixed by normalizing against a robust [5th, 95th] percentile range
instead of raw min/max -- same principle statisticians use to build a
scale that isn't dictated by a single extreme point. A genuine outlier
still scores at the extreme (0 or 1, via the same clamp norm() already
had), it just can no longer drag every OTHER cell's scale along with
it. The flat-area fallback (used when there isn't enough real variation
in the box to meaningfully differentiate cells) is computed from this
same percentile-based span now too, for consistency.

Verified in three stages: re-ran the exact isolated scenario that
proved the bug and confirmed both scenarios now produce the identical
normalization range and identical score for the same cell, closing the
gap completely; confirmed the flat-area fallback still correctly
triggers (a genuinely flat 300-cell test area still resolves to the
neutral 0.15 score, not a meaningless stretch); and checked degenerate
cases directly -- zero cells, one cell, two cells, and an all-missing
area -- to confirm each falls back sensibly rather than producing
NaN or a crash.

## Location-dependent disappearing data — chlorophyll and wind got SST's own backfill; wind's fix uncovered two more coordinate-system bugs along the way

Different from every issue before it in this thread: not a blocked
host, and not always-zero — genuinely different behavior depending on
where you look.

**Why this happens, physically, not just in code**: SST already has a
sophisticated multi-tier system that backfills gaps by pulling in
nearby days' data when today's own composite falls short of 90%
coverage. Chlorophyll and wind never had any equivalent — each is a
single day's satellite pass, and satellite passes have real, physically
expected gaps: cloud cover blocks chlorophyll's optical sensor entirely
in some spots, and a specific day's wind composite can simply miss a
particular small area. Different locations hit these gaps differently,
which matches exactly what got reported.

**The fix reuses data already being fetched, not a new request.**
Chlorophyll and wind's multi-day history -- already pulled for
persistence -- now also backfills today's own coverage gaps, filling in
only what's genuinely missing without ever overwriting a real today
reading, the same principle SST's own compositing already uses. Zero
new network calls.

**Two more coordinate-system bugs found building and testing this,
neither guessed at -- both caught by testing the actual before/after
coverage numbers, not just assuming the fix worked:**

1. The coverage check itself first used the scoring grid's own fine
spacing to decide "is this location covered" -- fine for chlorophyll's
resolution, but far too tight for wind's much coarser 0.25 degree grid, so
wind's own coverage read exactly 0% even immediately after a successful
backfill. Fixed by measuring each signal's own actual data spacing
instead of assuming one number fits every source -- the same
estimateSpacingMi approach already used elsewhere in this file for
exactly this reason.

2. Wind's raw data sits in 0-360 degree longitude before being converted back
to this app's normal -180/180 convention later in the pipeline. The
backfill's own coverage grid was built using the normal-range
coordinates, while it was checking them against data still in the
0-360 range -- two coordinate systems that never overlap, so nothing
could ever register as "close enough," independent of the spacing fix
above. Fixed by passing wind's own already-converted 0-360 bounds into
its two backfill calls specifically.

Verified in stages, each confirmed with real before/after numbers
rather than assumed: chlorophyll's coverage measurably improved (67%
before backfill, 100% after, using history data already in hand);
wind's own coverage was first shown broken (stuck at 0% even after a
successful merge) via direct testing, which is what caught the spacing
bug; fixed, then re-tested and shown correctly moving from a genuine
zero-coverage case to full coverage; and finally, with a real rotational
wind pattern in the backfilled data, upwelling computed a real,
non-zero value from what had been a total gap moments before --
confirming the earlier resolution fix and this round's coverage fix
both hold correctly together, not just individually.

## Upwelling showing exactly 0 m/s at several locations — a real, latent bug just exposed by wind finally working

Direct report, and a genuinely different kind of bug than everything
before it in this saga — not a blocked host, a real calculation error
that's been sitting there the whole time.

**The mechanism**: computing upwelling means sampling wind slightly
east/west/north/south of a point and looking at how the wind field
changes between them (its divergence). That offset was the scoring
grid's own spacing — about 0.033° across a 50-mile area — but wind data
itself only has real information every 0.25°, roughly 6x coarser.
When the offset is that much smaller than the wind data's actual
resolution, all four sample points can end up closest to the exact same
underlying wind grid cell. Comparing a value to itself always gives
zero change, so the divergence — and the reported upwelling — comes out
as exactly 0, regardless of what the wind is actually doing.

**Why this wasn't caught until now**: the old wind dataset was also
0.25° resolution, so this bug was always there — it simply never had
real wind data to run against, since that dataset was blocked outright.
The moment wind started actually returning values this round, this
became visible for the first time. Not a regression from the recent
fix; a bug the fix exposed by finally working.

**Fixed** with a wind-specific sampling offset (0.25°, matching wind's
real resolution) used only for this calculation — every other signal
(SST, chlorophyll, eddy, current break, structure) keeps using the
scoring grid's own finer spacing, since their source data really does
have that much resolution.

**Verified precisely, not just re-run through the full pipeline**:
tested the divergence calculation directly, at a point deliberately
aligned to sit exactly on a wind grid cell — the worst case for this
bug. The old offset produces precisely 0 for a wind field with a real,
strong rotational pattern built into it. The fixed offset, run against
the exact same wind data, produces a real, physically meaningful value.
Confirmed again end to end afterward: upwelling now reads consistently
non-zero across multiple locations in the same test area.

## Both chlorophyll and wind fixed — real, distinct root causes, each confirmed live before committing

Two dead ends had to be found and ruled out before this converged.

**Wind**: fully confirmed. `noaacwBlendedWindsDaily` shares the exact
host-level block affecting every `noaacw`-prefixed dataset. Switched to
CCMP daily near-real-time on `oceanwatch.pifsc.noaa.gov` — confirmed
live, not assumed: a real probe returned real wind data (status 200, six
non-null values). One genuine query bug found along the way: an earlier
attempt at this same dataset got a 400 error from an altitude dimension
bracket that doesn't apply here — this dataset's actual schema is just
time/latitude/longitude, confirmed directly rather than copied from the
old wind dataset's shape. Variable names are `uwnd`/`vwnd`, not
`u_wind`/`v_wind`.

**Chlorophyll**: the previous "replacement" (`nesdisVHNSQchlaDaily`)
turned out to be a dead end in a specific, informative way — its own
error response named a completely different dataset ID
(`noaacwNPPVIIRSSQchlaDaily`), which shares the exact same blocked
`noaacw` prefix as everything else. It wasn't a different source at
all, just a different name pointing at the same blocked place. Switched
to `erdMH1chla1day` — NASA/GSFC MODIS data, not a NOAA CoastWatch
product, a genuinely different pipeline. First attempt at this got an
HTTP 500 naming the wrong variable (`chlor_a`, carried over from the
VIIRS-dataset naming convention); found the real variable name
(`chlorophyll`) from an actual working query example, not another
guess, and confirmed it.

The pattern worth naming directly: two changes in earlier rounds looked
like fixes but were still guesses — a new-sounding dataset name and a
web search confirming a page exists are not the same as a real request
succeeding. Both new sources here were verified with an actual
successful response (status 200, real values back) before being written
into `forecast.js`, not before. Both are now fully independent of every
`noaacw`-prefixed dataset — different data providers, different hosts,
different underlying pipelines entirely, not just different-looking URLs
pointing at the same blocked source.

## Root cause finally confirmed by fact, not guesswork — and it was never a request-structure problem at all

The diagnostic report shared back settles this definitively. Every single
chlorophyll probe failed with HTTP 403 — including the dataset that had
already been swapped in as "the fix" for the earlier 403 problem. Every
wind probe failed the identical way. SSH, currents, GEBCO, and MUR all
succeeded, in the same run, from the same environment. The pattern is
unambiguous: `coastwatch.noaa.gov` itself is blocking every request this
app makes to it, regardless of dataset or query shape, while
`coastwatch.pfeg.noaa.gov` and `cwcgom.aoml.noaa.gov` both work fine.

**This means every previous round of guessing was solving problems that
weren't the actual problem.** Merging requests, decoupling reliability,
aligning dates by calendar day — all real, defensible engineering, and
none of it could have fixed a host-level block, because the problem was
never about how the requests were shaped or sequenced. It was about
which server they were going to.

**Chlorophyll is fixed — switched to a genuinely different host.**
`nesdisVHNSQchlaDaily` on `coastwatch.pfeg.noaa.gov`, confirmed to exist
with a real web search (not assumed from a comment) — same `chlor_a`
variable name, same ~0.0375° resolution. One real cost worth being direct
about: this replacement is a "science quality" product with a
documented ~15-day processing latency, not the near-real-time data the
app previously expected. Its own history window was widened from 4 days
back to 20, specifically to accommodate that — the shared 4-day window
would have requested a date range entirely before any data existed at
that latency, always returning empty.

**Wind is not fixed.** It hits the exact same blocked host, confirmed by
the same diagnostic report, but a suitable near-real-time replacement on
a working host wasn't found in the time available. Upwelling will
continue to be absent — the app already handles this gracefully (no
crash, no cascading failure into other signals, confirmed directly in
testing), but it's a known, current gap, not a hidden one.

**Persistence itself is likely still going to come up empty most of the
time, for a new and different reason than before.** Chlorophyll's
replacement is systematically ~15 days behind SST, SSH, and current
data. The date-alignment logic added specifically to prevent comparing
mismatched days across signals will, as designed, correctly refuse to
call chlorophyll's 15-day-old reading and SST's same-day reading "the
same calendar day" — so the intersection of dates across all four
signals will likely still come up empty, even though each one now works
independently. That's the alignment safeguard doing exactly its job,
just against a genuinely new mismatch this fix introduced rather than
the old one. Worth deciding deliberately rather than patching again on
guesswork: either persistence needs a same-day-latency chlorophyll
source (harder to find), or the date-matching tolerance needs to
explicitly account for chlorophyll's slower cadence rather than
requiring exact calendar-day agreement.

Verified directly: a test simulating the new host succeeding while the
old, blocked one throws if ever contacted confirms chlorophyll's signal
and star rating both come through correctly, and that the app still
degrades cleanly where wind remains blocked.

## Reported still missing after the last fix — reverted that fix and addressed the actual risk it created

Direct, honest account: the previous round's "merge today+history into
one fetch" change didn't resolve this, and reported still happening
means it's worth being straightforward about rather than guessing a
third time in the same direction.

**What that merge actually did, on reflection**: chlorophyll, SSH, and
wind's "today" signal used to come from its own small, fast, independent
request. Merging it into the same fetch as history meant today's core
signal now depended on a request that has to pull several days of
gridded data instead of one, then coupled that heavier, inherently more
timeout-prone request to both today's reading AND persistence at once.
If that fetch is ever slow or fails — and there was no way to confirm
whether it was network contention, response size, or something else
without live access to the actual services — it now took today's real
signal down together with persistence, not persistence alone. That's a
plausible, structural explanation for exactly what got reported: not
persistence being merely rare, but chlorophyll going missing right
alongside it.

**Reverted rather than patched further.** Chlorophyll, SSH, and wind are
back to two independent fetches each: their own small "today" request,
and a separate history request purely for persistence. This does mean
two requests to each of those three hosts again, the exact thing the
previous merge was trying to avoid — but a core signal's reliability
depending on a bonus feature's fetch succeeding is a straightforwardly
worse trade than a few extra concurrent requests, regardless of which
concern turns out to matter more in practice.

**Verified the specific failure mode directly, not just re-run the old
tests.** Built a test simulating exactly the scenario this needed to
survive: chlorophyll/SSH/wind's history requests fail outright (HTTP
500) while their separate today requests succeed normally. Confirms
`sources.chlorophyll`, `sources.altimetry`, and `sources.upwelling` all
still read true, the Chlorophyll and Eddy star ratings still appear —
and Persistence correctly and cleanly disappears on its own, without
taking anything else down with it. That last part is the actual point:
persistence failing alone, silently, is the acceptable outcome for a
bonus feature; chlorophyll disappearing because persistence's fetch had
a bad day is not, and shouldn't be structurally possible anymore.

## Root cause found and fixed: chlorophyll and persistence both going missing traced to the same structural bug

Reported as two separate problems; investigation found one shared cause.

**The actual bug**: when eddy, chlorophyll, and upwelling history were
added, each got its own new fetch — but their "today" snapshot was
*already* a separate, existing fetch to the exact same dataset. SST
never had this problem, because SST's "today" (hourly/ACSPO) and its
history (MUR) genuinely are two different datasets. Chlorophyll,
SSH/eddy, and wind aren't — "today" and "history" for those three point
at the identical URL, just with a different date range. That meant three
hosts that used to get one request each were suddenly getting two,
concurrently, every single forecast run. That's a real, structural
reason multiple signals could go missing together rather than
independently — not a coincidence of timing, and not something a retry
would reliably paper over.

**Fixed by removing the duplication, not by adding resilience around
it.** Chlorophyll, SSH, and wind now make exactly one request each,
covering the same date range their new history fetch already needed —
since that request already ends at "(last)," its own most recent frame
already *is* today's snapshot, with zero need for a second request to
fetch what the first one already had. Total new requests introduced by
last round's persistence work drops from four net-new fetches to zero —
today's chlorophyll/SSH/wind draw from data that would have been fetched
anyway.

One follow-on correction this required: the history-day list for these
three signals now explicitly excludes that same most-recent frame before
being used for persistence, since it's doing double duty as "today" —
without that, persistence would silently compare today against itself.

Verified directly, not just reasoned through: confirmed
`sources.chlorophyll` reads `true` and a real "Chlorophyll" star rating
appears in the output using only the merged fetch, and re-ran the full
three-scenario persistence test from last round to confirm the
continuous intersection scoring still holds with the new fetch structure
underneath it.

## Persistence made continuous, not binary

Direct correction — same principle already applied to the neighborhood
search radius itself (linear decay by distance, not a hard cutoff at the
boundary), now applied to persistence's own notability check. Worth
being precise about what was and wasn't already continuous: the
*neighborhood search* (how far a signal can be found from a cell and
still count, weighted by distance) already worked this way. What stayed
binary was the *notability* decision on top of that — each signal either
cleared its threshold on a given day or it didn't, all four had to clear
simultaneously, and the resulting day either counted as "1" or it
didn't. That's the piece this fixes.

Each prior day now gets a continuous 0-1 "intersection strength" instead
of a yes/no: the four signals' own normalized strengths (same
normalization ranges as before, just without the ≥0.55 cutoff applied to
each) are combined by taking their MINIMUM, not an average — an
intersection is only as strong as its weakest member, so one very strong
signal can't paper over three weak ones. These daily strengths sum
directly into `persistenceDays`, capped at 2.0 (the same ceiling the old
discrete count had), and `persistenceBonus` uses the exact same linear
formula as before (1.0 + 0.06 per day-equivalent) — just fed a continuous
input now instead of jumping between three fixed steps. The star
rating's displayed fraction now shows one decimal place (e.g. "1.1/2")
rather than a whole number, an honest reflection of the new scale rather
than rounding away the thing that changed.

Verified with three scenarios, not two — the third is the one that
actually proves this is continuous rather than just "a different pair of
binary outcomes." All four signals genuinely strong on both days scores
near the 2.0 ceiling (1.94); chlorophyll genuinely flat (no gradient at
all, not just "weak") correctly zeroes the day out entirely, since the
minimum-of-four collapses to zero regardless of how strong the other
three are; and — the direct test of gradational behavior — chlorophyll
at a deliberately intermediate strength produces a score that lands
strictly between those two, not snapped to one end or the other.

## Number of forecast points made adjustable (1-15, default 5); settings reorganized into Units and Forecast submenus

Two related requests, built as one coherent restructuring since the
second reshapes how the first is delivered.

**A real, server-side limit found and made configurable, not just a
client-side display slice.** The count of returned top spots was
hardcoded — `if (topSpots.length >= 5) break` — directly in the
spot-selection loop in `forecast.js`, so this had to be a server change,
not something the client could fake by showing fewer of a fixed batch.
Added a `pointCount` request parameter, re-validated on the server
regardless of what's sent (clamped to 1-15, default 5 for anything
missing or out of range) — a request parameter is never trusted to
already be honest about its own bounds. Checked that 15 is actually
achievable given the scoring grid's own density (18×18 cells, ~144
possible spatially-distinct slots at the existing minimum-separation
rule) before assuming the upper end of the range would work, not just
the middle of it.

**The settings panel is now genuine navigation, not just more grouped
sections.** A main screen lists "Units" and "Forecast" as tappable rows;
each opens its own sub-view with a back row, rather than one longer flat
list. The three existing unit groups moved into the Units sub-view
unchanged; the new point-count slider (1-15, live-updating number
alongside it) lives in the new Forecast sub-view. Reopening settings
always lands back on the main list — a previously-visited submenu is
never what greets the next visit, checked directly: opened settings,
navigated into Forecast, closed and reopened, confirmed the main list
was showing again, not the submenu left behind from before.

**Verified the full path end to end, not just the UI in isolation.**
Since this environment can't reach a live network to test the actual
outgoing request the normal way, the fetch call was intercepted directly
at the JavaScript level rather than skipped: set the slider to 9,
confirmed the preference persisted through a page reload, then confirmed
the actual URL `runForecast()` builds includes `pointCount=9` — the real
value chosen, carried all the way from the slider to the request itself.

## Contours panel repositioned left of its button; opacity row centered

Direct request, both measured precisely rather than eyeballed. The panel
was floating above the button before; now it sits directly to its left
with an 8px gap and no overlap, vertically centered on the button rather
than just placed at some offset — confirmed on the real rendered layout:
panel's right edge lands exactly 8px short of the button's left edge,
and their vertical centers land within half a pixel of each other.

The opacity slider previously stretched to fill the full width of the
panel (`flex:1`), which meant the row spanned edge to edge rather than
reading as a centered group. Given the slider a fixed width instead and
centered the row as a whole, so "Opacity" and the slider now sit as one
compact unit in the middle of the panel — checked directly against the
panel's actual content area, left and right margins land within about 2
pixels of each other.

## Contours button now toggles directly, matching the currents button's own pattern

Direct request: click turns contours on, click again turns them off, no
separate on/off button in the submenu needed. Removed that button
entirely rather than keep it around unused.

Matched an existing pattern already in this app instead of inventing a
new one: `fab-currents` already toggles its layer directly on click, no
panel involved at all. This button still has a panel — the opacity
slider is still useful and wasn't asked to go — so its visibility is now
tied directly to the on/off state instead of being an independent
open/close concept: it shows automatically while contours are on, hides
when they're off. Taken out of the "close on any map tap" list that
applies to other dropdown-style panels, since that behavior no longer
fits — hiding the opacity slider while contours stayed on would leave no
way back to it except clicking the FAB, which would turn contours off
instead.

Verified the full state machine directly, not just the first click:
starts off, first click turns on (button highlights, panel appears),
second click turns off (both reverse), third click turns back on again
— and the opacity slider still adjusts correctly while active.

## Contours icon expanded toward 90% of the button diameter — and a real sizing bug caught and fixed along the way

Direct request. Straightforward on its face — just increase the icon's
display size — but measuring the result to confirm it actually landed at
90% surfaced a genuine, pre-existing bug worth explaining rather than
quietly working around.

**Setting the SVG's CSS width had no effect; height worked, width
didn't, consistently landing at 34px regardless of what was actually
set.** Confirmed this wasn't a fluke of one measurement — checked with
`getBoundingClientRect()` directly, with a cache-busted fresh page load,
with explicit `width`/`height` attributes added to the `<svg>` tag
itself — same 34px width every time, while height tracked correctly.
The exact cause wasn't fully identified (nothing in this file's CSS
targets that value directly), but the fix that reliably worked was
explicit: `!important` plus `flex-shrink:0` on both icons' sizing rules.

**Checked whether this also affected the forecast icon from two rounds
ago, rather than assuming it was isolated to this one — it did.** Same
34px-width ceiling, meaning that icon has been rendering slightly
narrower than its intended 38px this whole time (a mild horizontal
squeeze, not something dramatically visible, but a real discrepancy from
what was reported as delivered). Fixed the same way, restored to its
actually-intended 38px, and reflagged directly rather than left quietly
corrected: the diameter percentage reported for it in an earlier round
undersold it slightly. It measures at about 74.5% now that it's actually
rendering at its intended size, not the 66% reported when the bug was
still silently in effect.

With sizing now genuinely responsive to the CSS instead of capped, the
contours icon's own size was tuned by direct measurement rather than
calculation: 44px measured at 91.1% of the button's diameter, 43px at
89.1% — both close, but 44px sits marginally nearer the requested 90% and
was kept. Zero pixels fall outside the button's circular edge at that
size, confirmed on the actual packaged file, not just a preview render.

## Contours icon re-traced properly, and a real method flaw caught before delivery

Same tracing pipeline as the two forecast-icon rounds — real contour
detection on your actual reference image, not hand-drawn — applied to
the topographic contour-lines reference from much earlier in this
project. The outer circle boundary was identified and excluded the same
way as before (its darker line color separated cleanly from the lighter
gray circle at a simple brightness threshold, confirmed by checking that
no kept shape's bounding box matched the full image size), and the
traced artwork fills the viewBox with the same minimal margin used for
the forecast icon.

**Caught a real problem before it shipped, worth explaining rather than
skipping past.** The initial trace reused the forecast icon's method
exactly — treating each traced line as a filled shape — and it measured
almost nothing on screen: 98 lit pixels on the actual button, against
2,842 for the forecast icon done the same way. The reason is specific to
what this image actually is: the sailfish reference has substantial
filled areas (the body, the brain) that hold up fine as filled shapes at
small size. This reference is nearly all thin lines, and a thin line's
*filled* outline can shrink to sub-pixel width once scaled down —
effectively disappearing — in a way a deliberately stroked line doesn't,
since a stroke has an explicit, guaranteed width independent of the
source geometry's own thinness.

Fixed at the method level, not by pushing the same approach harder:
skeletonized the thresholded image first to pull out each line's true
1-pixel centerline, traced *that*, and rendered the result as genuinely
stroked paths with an explicit width — matching how every other icon in
this app (including the original hand-drawn version of this one) already
works, rather than the fill approach that happened to suit the sailfish's
different kind of artwork. Re-measured after the fix: 7,509 lit pixels on
the real button, denser than the forecast icon's own 2,842, which tracks
— this reference is mostly line coverage across the whole circle, that
one is a few solid shapes with real gaps between them. Zero pixels fall
outside the button's circular edge, and the artwork now spans about 70%
of the button's diameter.

## Forecast icon expanded to fill the button

Direct request. Two things were actually holding this back, and both
needed fixing: the traced artwork itself still had a real margin inside
its own 24x24 coordinate space (was 1 unit, now 0.3 — the shapes fill
about 98% of it now instead of ~92%), and the icon's own display size in
the button was 22px, the same as every other, much simpler icon here —
never increased for one carrying this much more detail.

Sized specifically for this icon rather than just picking a bigger
number: 38px, the largest size that stays entirely inside the button's
own 48px circular edge without corners poking past it into the square
corners a round button doesn't actually have. Verified concretely, not
assumed: measuring the icon's own light pixels directly on the real
rendered button, zero of them fall outside the circular boundary, and
the artwork's width now reaches about two-thirds of the button's
diameter — a real, measured increase from roughly 40-46% before.

## Forecast icon re-traced from the new, cleaner reference image

Same tracing method as last round (real contour detection on the actual
image, not hand-drawn), applied to the new source you provided instead
of assumed to already be good enough. The new image is a flat, clean
illustration on a plain white background rather than a photo of a 3D
badge mockup with lighting and shadow — worth checking whether that
mattered rather than assuming the method alone would fix it.

It measurably did: the earlier badge photo's shading and dimensional
rendering were adding noise the trace had to contend with. Counting
distinct shapes at the button's actual real size, the same measurement
used to evaluate the previous attempt, went from 5 up to 9 with this
cleaner source — more of the real linework is surviving intact, not lost
to compression or lighting artifacts in the source photo. No outer
circle was present in this image to begin with, so nothing needed
excluding there. Same verification as before: checked at preview size,
re-measured directly on the actual button cropped from the real shipped
file, and confirmed the JS still runs clean.

## Forecast icon rebuilt a third time — traced directly from your image's actual pixels this round, not approximated

Direct, accurate correction: the previous version was hand-drawn from
memory of what the reference looked like, and that's exactly the kind of
approach that drifts from the source — confirmed by your report that it
looked nothing like the image you gave me.

**A fundamentally different method this round, not just another attempt
at the same one.** Rather than draw shapes by hand again and hope they
matched better, this traced the actual reference file directly: every
dark pixel in your uploaded image was isolated, OpenCV's contour
detection found the real boundary of every distinct shape in it (39 of
them, once the outer circle — found and excluded by its two much larger,
isolated contour areas — was set aside), each was simplified just enough
to stay clean without losing its real shape, and the coordinates were
scaled directly into the icon's viewBox. The path data in the button now
comes from measurements of your actual image, not from a redrawn
impression of it — coloring, scaling, and removing the outer circle
really are the only edits, because the shapes themselves were never
redrawn at all.

**An honest limit worth naming, found by measurement, not assumed:**
counting distinct shapes in the original (39) against the same count
run on this icon rendered at the button's real ~48px size (5) shows most
of the source's finest interior detail — individual sail-rib lines,
the brain's fold marks, individual ray ticks — visually merging at that
scale. That's the physical reality of a 22px icon carrying an amount of
line detail an illustration this size can hold: it's not a simplification
made this round, and the traced data itself hasn't been altered to
compensate for it. The overall composition and every major shape's
silhouette — the brain, both clouds, the sailfish, the wave lines — are
present and positioned exactly as measured from the source; the visible
result is what genuinely happens when that much real detail is displayed
this small, not a redesign decision.

## Settings icon: gear swapped for a hamburger

Direct request. Three horizontal lines, same size and `currentColor`
pattern as the gear it replaces, so it sits in the header exactly the
same way. No other part of the settings feature changed — same button,
same click behavior, same dropdown.

## A real bug: JS-style unicode escapes leaking into raw HTML

Direct report, and a genuine mistake from the settings work: eight spots
in that new HTML — the temperature and coordinate-format option labels,
the gauge's unit label, the color-scale panel's two unit labels — used
`\u00B0` (and `\u2032`/`\u2033` for the prime marks in DMS coordinates)
directly in HTML markup. That escape syntax means something specific
inside a JavaScript string; outside one, in plain HTML text, a browser
has no reason to treat it as anything other than six literal characters.
It rendered exactly as reported: the code itself, not the symbol.

The four other places already using this pattern were all fine, because
they're genuinely inside the `<script>` block, in real JS string literals
(the coordinate-formatting functions, the temperature-label helper) —
correct there. The eight broken ones were HTML markup, where that syntax
never applied. Root cause: writing the HTML and JS in the same pass and
using one convention for a symbol that needed to be written two different
ways depending on which of the two it landed in.

Fixed by replacing all eight with the literal UTF-8 characters directly
— the file already declares UTF-8 and already uses literal special
characters successfully elsewhere in its comments, so this isn't a new
pattern, just applying the one already established. Swept the entire
document for any other instance of this same mistake before considering
it done, not just the specific characters that were reported — zero
found. Confirmed three ways before calling it fixed: the raw file bytes
now show the real characters, the JS still parses without error, and —
since this is exactly the kind of thing that can look right in a text
diff while still rendering wrong — the actual page was loaded in a real
browser and the genuinely rendered DOM text was read back, confirming
"Fahrenheit (°F)" and "27° 27.40′ N" display as the real symbols, not
their escape codes.

## Forecast button text simplified; a settings dropdown added for units and coordinate format

**The pill button**: down to exactly "Update Forecast," per direct
request — the area-cap sublabel and the "Run" vs "Update" state
distinction are both gone. The spinning icon and disabled state already
communicate "in progress" during a fetch, so no loading-specific text
swap is needed either; one label, all the time.

**The settings feature is a genuinely large addition**, not a small
tweak, so it's documented in full. A gear icon in the header (right of
the wordmark, via `justify-content:space-between` on the topbar) opens a
dropdown with three independent preferences — distance (nautical miles /
statute miles / kilometers), temperature (°F/°C), and coordinate format
(degrees-decimal-minutes / decimal degrees / degrees-minutes-seconds) —
persisted the same way home port already is (a `bwi_` key in
localStorage, each field validated independently on read so a corrupted
or unrecognized value in one doesn't invalidate the other two).

**A deeper wrinkle than it first looked**: the SST color scale's entire
internal model turned out to be natively in Fahrenheit — the adjustable
min/max range, its reset defaults, the values sent to the tile layer, all
of it — with Celsius conversion only ever happening at the one point
that actually talks to the tile server. Making the *display* respect a
temperature preference without touching that internal model was the
right scope: `colorMinF`/`colorMaxF` still always hold °F internally, so
the tile-layer conversion code is completely unchanged; only the gauge
labels and the adjustment panel's inputs convert for display, and convert
back on submit. Skipping this piece would have left a real, visible
inconsistency — the main gauge in °C while its own adjustment panel
stayed in °F — so it's included, not left as a known gap.

**Every existing coordinate and distance display was found and
redirected**, not just a new one added alongside the old: all seven
`formatDDM` call sites (the coord card, forecast results, saved points,
home port) now go through a single `formatCoords` that dispatches to
whichever of the three formats is active; both distance displays (home
port distance, the measure tool) go through one `formatDistance`. A
settings change re-renders whatever's currently on screen immediately —
gauge, an open coord card, an active measurement, even an
already-displayed forecast result (its last response is now kept in
memory specifically so this can happen) — rather than only affecting
whatever gets shown next.

**Verification here needed a different approach than the last few icon
rounds**, and is worth explaining rather than glossing over. This app
needs a real Leaflet map to finish initializing, which needs network
access this environment doesn't have — every earlier attempt at
rendering the live app hit `L is not defined` and stopped before any of
this code ever ran. Solved properly rather than skipped: built a minimal
Leaflet stand-in (just enough of the API surface — `L.map`,
`L.tileLayer.extend`, a real `L.latLng` with working `distanceTo`) to let
the app's actual `init()` sequence complete for real, then drove it
like a genuine user would — clicking the real settings button, firing
simulated taps through the app's own actual `onMapClick` handler rather
than calling internal functions directly, reloading the page to confirm
`localStorage` persistence survives a real reload. Confirmed concretely,
not assumed: temperature conversions matched by hand-checked math (85°F
correctly reads 29°C), a 1-degree-of-latitude measurement correctly read
"60.04 nm" then live-updated to "69.09 mi" the instant the preference
changed, and coordinate format switched from DDM to DMS on an
already-open coord card without a new tap. Checked once more directly
against the actual zip's contents, not just the working copy, the same
discipline used throughout this project.

## Two button icons redesigned, actually rendered and inspected before delivery

Direct request: a circle-and-crosshairs symbol for the location button,
and a topographic-contour symbol for the depth button, matching a
reference image, styled to fit the app's existing color scheme.

**Not designed blind.** This is a visual task, and reasoning about SVG
coordinates in the abstract isn't the same as knowing what they look
like. Found an actual, working path to verify: Playwright's Chromium
binary was already present in this environment, so both candidate icons
were rendered to real PNGs and inspected directly — not assumed correct
from the markup alone.

The first pass at the contour icon, drawn by hand, looked tangled and
crossed over itself once actually rendered — nothing like clean nested
bands. Rebuilt it properly instead of eyeballing coordinates a second
time: a small script generates one irregular "terrain" outline using a
few sine harmonics, then produces four correctly-nested copies of that
same outline at different scales, so the bands are genuinely parallel by
construction rather than independently hand-drawn curves that happen to
cross. A small offset dot marks a "peak," echoing the reference image's
own off-center high point. Verified at three checkpoints, not just once:
the initial (still-flawed) version, the corrected version at a large
preview size, and finally at the icon's true 22px display size inside an
actual 48px button — in both its normal and active (selected) color
states — before it went anywhere near the real file.

Color scheme: both icons use `stroke="currentColor"`, the same pattern
every other icon in this app already follows — automatically inheriting
whatever color the button itself is currently rendering in (the neutral
default, or the accent color when a layer is toggled on), rather than a
hardcoded color that would only look right in one of those two states.

Confirmed a final time by rendering the actual shipped `index.html`
directly (not the standalone preview file) and cropping into the FAB
stack, so what's in the archive is what was actually checked.

## Cap corrected back to 50x50 miles; forecast button restored to the stack; run-button label split to stay clear of it

**The cap, corrected**: "50 square miles" from an earlier round was a
literal misreading — the actual intent was always a 50-mile SIDE (2,500
sq mi total), same as originally, not a ~7-mile-side square. Reverted the
formula in both the server and client back to a direct 50-mile cap,
keeping the square-shape mechanism (from that same earlier round) intact
— only the cap's size changed back, not the shape requirement.

**The forecast button, back in the stack.** It had been relocated to the
bottom-left specifically because it was colliding with whatever sits in
the top-right corner on a short viewport. Moved back to the top of the
right-side stack per direct request — worth being direct that this
un-does that specific fix, and the same class of collision could recur on
a short enough window. Restored using the exact spacing already in place
for the other four buttons (the same spacing that was tightened two
rounds ago specifically to keep the attribution-banner clearance without
pushing the top of the stack any higher), so the forecast button lands at
precisely its original pre-relocation position — nothing reintroduced by
accident beyond what moving it back necessarily reintroduces.

**The run button's label, split to stay clear of the (now-restored)
stack.** With the button back in the stack and the label now including
area info, a long single-line label — centered, non-wrapping — risked
reaching that column on a narrow screen. Restructured into two lines
instead of one: the action text ("Run forecast for this area" / "Update
forecast for this area") on top, "up to 50×50 mi" smaller and dimmer
underneath — narrower than the combined single line was, since neither
line alone needs to be as wide. Backed by a hard `max-width` on the
button itself as a second, independent guarantee (not just hoping the
two-line split is enough) — text truncates gracefully in the extreme
case rather than ever overlapping anything. The sublabel hides during the
transient "Analyzing conditions…" state, since a loading message isn't
really "for this area" framing, and reappears once a result or the
pre-run label shows.

## The area-cap text merged into the run button; the separate label removed

Direct request: the "50 sq mi" text moved into the run button itself
("Run forecast for this area (up to 50 sq mi)", and "Update forecast for
this area (up to 50 sq mi)" once a forecast has run), and "Current map
area" is gone entirely rather than left as a shorter, now-orphaned label.

With both pieces of its content either moved or deleted, the standalone
zone-label pill had nothing left to show, so it's removed outright —
HTML, its CSS rule, and both places in the JS that referenced it (setting
its text, and hiding it when forecast mode closes) — rather than left
sitting empty in the layout.

## The forecast box redesigned: always a square, and a genuinely different cap

Two distinct requests, not one bigger number. "50% of the window" changed
the existing fraction (was 65%). "Up to 50 square miles" is not a
rewording of the previous "50 mile" cap — the old cap was a 50-mile SIDE
(2,500 sq mi total); 50 square miles of actual area is a side length of
about 7.07 miles, roughly 350x smaller. Read literally rather than
assumed to mean the same thing, since the person asking has been
precise throughout this project and the distinction is real.

**Square, genuinely, not just usually.** The box previously matched
whatever aspect ratio the map viewport itself happened to be — wider than
tall on a landscape view, taller than wide on portrait, matching neither
on an oddly-shaped window. Rebuilt into one unified formula instead of
the old two-branch cap-or-inset logic: take the SMALLER of the viewport's
two real-world-mile dimensions (so the square fits within a narrow
portrait viewport on its constraining axis, not just its wider one), use
50% of that as the side length, capped at the side length that gives
exactly 50 sq mi of area. "50% of the window, up to 50 sq mi" turned out
to be one bound, not two rules — whichever constraint is tighter right
now wins, with nothing to reconcile between them.

Verified directly, including the case most likely to expose a mistake: a
deliberately non-square viewport (~61 miles wide, ~1.4 miles tall) still
produces a perfectly square analyzed box, sized correctly off its
constraining (shorter) dimension — not a rectangle, and not sized off the
wrong axis. Checked identically against the client's own copy of this
formula (which draws the box) and the server's (which analyzes it), same
discipline as every area-shape change in this project.

**A real, substantive consequence — not touched, but named directly**:
the 5-mile neighborhood-decay radius used throughout scoring (SST break,
chlorophyll edge, eddy, current break, structure, upwelling) was tuned
against the old, much larger 50-mile-cap world. At the new, much smaller
maximum area (~7.07mi per side, corner-to-corner distance under 10mi),
that same 5-mile radius now reaches across nearly the entire box from any
given cell — the neighborhood search still works exactly as designed, it
just has much less room to be selective within now. This wasn't changed,
since retuning it wasn't asked for and is a real, separate design
decision — but it's worth knowing it's there before hitting it as a
surprise. Several existing tests needed rescaling to keep working at the
new size for the same underlying reason — a test point "5+ miles from a
feature" simply doesn't exist within a 7-mile-wide box anymore, so those
were rebuilt at proportionally smaller distances rather than skipped.

A genuine side benefit, not engineered for directly: with far less area
to fetch and score per request, handler time in testing dropped from
roughly a second to about 130ms.

## FAB stack cleared from the attribution banner; a real first-tap positioning bug fixed; chlorophyll/altimetry legend overlap needs one more detail

**The FAB stack and the OpenStreetMap/Carto attribution banner**: the
bottom-most toggle button (Measure) sat at exactly the same corner
Leaflet's attribution control defaults to. Moved the whole stack up 16px
to clear it — but also tightened the spacing between the five stacked
buttons by 4px each (58px center-to-center down to 54px) so the TOP of
the stack lands in the same place it did before. Moving the base up
without doing that would have also pushed the top button 16px closer to
the legend in the top-right corner, which risks trading one overlap for
another rather than fixing it.

**A real, precisely-diagnosed bug in the crosshair positioning, not
solved on the first attempt.** The card's height was measured before its
depth line — which arrives from an async fetch — had any text in it at
all on the very first tap of a session, since fetchDepthAt used to set
even its own "Depth: checking…" placeholder AFTER the card was already
positioned and shown. Every tap after the first accidentally avoided
this only because the previous tap's leftover depth text was still
sitting there, already reserving roughly the right amount of space —
never because the underlying bug wasn't happening. Fixed at the root,
in two parts: the placeholder now gets set before the first
measurement runs, not after, and the card now also re-measures and
re-positions once the real depth text lands, in case a longer result
(a deep spot's "Depth: 5,280 ft (1,609 m)", say) wraps to more lines
than the placeholder did — something the first fix alone couldn't
anticipate.

**The chlorophyll/altimetry legend overlap, honestly**: this one I
worked through carefully but couldn't fully confirm. All three legend
variants (SST, chlorophyll, altimetry) are structurally identical, so a
per-page height difference doesn't explain it, and the page-switching
logic correctly hides all three before showing the one relevant page's
own — so two legends were never both on screen simultaneously. The
dimensions do suggest a genuinely plausible mechanism: on a short enough
map viewport, the legend (top-right) and the FAB stack (bottom-right,
totaling roughly 300px tall) could reach far enough to meet in the
middle — which would make "chlorophyll and altimetry specifically" more
about screen/window height than the page itself. Rather than guess
further and risk another incomplete fix, this one is flagged directly:
a specific detail — which exact button it touches, or the rough window
size it happens on — would settle it precisely instead of another round
of code-reading alone.

## Viewport inset tightened from 85% to 65%

Direct follow-up. A single-value change (`VIEWPORT_INSET_FACTOR`, 0.85 to
0.65) in both the client's and server's identical copies of the inset
logic — the mechanism itself, added last round, is unchanged. Re-verified
the same two guarantees still hold at the new value: a zoomed-in viewport
now produces an analyzed area at exactly 0.65 of the original span (not
just close to it), still centered on the same point; a zoomed-out
viewport still produces exactly 50 miles, confirming the tighter inset
still doesn't leak into the capped case.

A couple of existing tests needed updating as a direct, mechanical
consequence, not because anything was actually broken: a tighter inset
shrinks the analyzed grid further, so a test with hand-picked coordinates
near the edge of that grid could fall just outside it. One test's
requested area was widened to keep its target points inside the smaller
analyzed area. A second was rebuilt to look up the nearest actual cell to
a target point rather than requiring an exact coordinate match within a
fixed tolerance — a more robust fix than re-tuning coordinates by hand
again, since it stops depending on the exact inset value at all and will
keep working if this gets adjusted further.

## When zoomed in, the forecast box is now inset from the viewport, not flush with it

Direct request. Before this, the analyzed area exactly matched the
current map viewport whenever the viewport was already smaller than the
50-mile cap — meaning at any reasonably zoomed-in view, the dashed box's
edges landed exactly at the edges of the visible map. A rectangle whose
boundary coincides with your entire field of view is hard to perceive as
a distinct shape at all.

**An important existing guarantee shaped how this got built**: the box
shown on the map has always been documented, repeatedly, to exactly match
what the server actually analyzes — not a cosmetic approximation of it.
Simply shrinking the drawn rectangle without changing what forecast.js
analyzes would have broken that guarantee, showing a box that no longer
represented the real analyzed area. So this went into both places: the
actual analyzed area shrinks now, not just its on-screen drawing, keeping
"the box matches what's analyzed" true rather than making it a visual
approximation.

**The mechanism**: when the current viewport already fits within the
50-mile cap (so the existing cap logic doesn't need to engage), the
analyzed area is inset to 85% of the viewport, centered the same way —
roughly a 7.5% margin on each side, enough to read as a distinct
rectangle with visible map around it. The 50-mile cap itself, for when
someone is zoomed out further than that, is completely unchanged — the
two never stack; a viewport that needs capping gets capped to exactly 50
miles, not 85% of 50.

**Verified two ways, on both sides of the mirror**: a small, zoomed-in
viewport produces an analyzed area at exactly 0.85 of the original span
on both axes, still centered on the same point, with `areaWasCapped`
correctly staying false (an inset isn't a cap — different mechanism,
different meaning). A large, zoomed-out viewport still produces exactly
50 miles, confirming the inset doesn't leak into the capped case. Checked
identically in the client's own copy of this logic (which draws the box)
and the server's (which actually runs the analysis), since a client/
server mismatch here would be exactly the kind of bug this guarantee
exists to prevent.

## Tap marker changed to a crosshair; a real popup-overlap bug fixed; the obsolete color-matching hint removed

**The marker**: direct request, from a hollow white ring to a small
crosshair — four short lines with a gap around the center and a small
center dot, the same convention camera viewfinders and map-pin reticles
use to mark a precise point unambiguously. Built as a divIcon with an
inline SVG, matching how every other custom marker in this app (current
arrows, home port) is already built, rather than introducing a new
pattern. White with a dark outline baked into the SVG itself (a second,
wider dark stroke underneath the white one), so it stays visible against
any underlying map color — SST, chlorophyll, and current overlays span
the full color spectrum, not just water tones.

**A real, quantified popup-overlap bug, not just a request taken on
faith**: the card's positioning function already tried to avoid covering
the tapped point — sit above it by default, flip below if there wasn't
room — but the on-screen clamp that kept the card from running off the
bottom edge could override that gap entirely. Tested the exact scenario
directly: tapping near the vertical middle of a short map view, where
neither "fully above" nor "fully below" has room for the whole card, the
old logic placed the card 90 pixels into the crosshair itself, not just
close to it. Rebuilt so the gap is a hard guarantee — the card's position
is always exactly one of two values (fully above or fully below, with the
same fixed clearance), never anything the clamp can pull back toward the
tap point. In the rare squeeze case where neither direction fully fits,
whichever side has more room is used, and the card is allowed to extend
slightly past the visible margin there — a minor off-screen edge being
clearly preferable to it ever covering the exact spot it's describing.
Verified across four scenarios directly, including the specific squeeze
case that broke before: the gap held at exactly 18px in every one.

**The hint text removed** — "match the ring's color to the gauge" — was
tied directly to the old hollow-ring design (the ring was deliberately
unfilled specifically so the map color underneath stayed visible for that
comparison). Once the marker became a crosshair, that hint no longer
described anything real, so it's gone along with the now-empty element
that displayed it and a nearby stale comment that still referenced "the
ring" as the reliable substitute for reading pixel colors directly (a
real technical limitation, explained elsewhere in the code, that remains
true — only the specific workaround description needed updating).

## SST break, chlorophyll, eddy, current break, and upwelling: all now area-relative, matching structure

Direct extension of structure's redesign to five more signals, per direct
request. Rather than six separate copies of the identical min/max/
normalize/flat-area-safeguard logic, this became one shared helper
function, called once per signal — the kind of refactor that pays for
itself the moment a third signal needs the same treatment.

**The mechanism, unchanged from structure**: each signal is scored
relative to what THIS specific analyzed area actually contains, not one
fixed global threshold applied everywhere. Verified directly for SST
break specifically, not just assumed to work because the formula is
shared: the identical 0.8°C gradient scores 0.15 in a dynamic area (range
0.5-2.5°C) and 1.00 in a quiet one (range 0.1-0.8°C) — same number,
genuinely different rating, because what's remarkable depends on the
area. The same flat-area safeguard applies to all five: a genuinely quiet
area doesn't get its own noise stretched into a false "5-star extreme"
rating. Each signal's flat-area threshold reuses that signal's own
original global norm() lower bound (0.1°C for SST gradient, 0.05mg/m³ for
chlorophyll, 0.02m for eddy, 0.05m/s for current break) — not a new,
arbitrary number, but that original calibration repurposed as "is there
any signal here at all," while the actual star scoring becomes purely
relative to what's present.

**A genuine, deliberately-flagged tension with upwelling.** The other
five are all unsigned "how much does this change" measures with no
meaningful zero point of their own — area-relative normalization fits
them cleanly, the same way it fits structure. Upwelling is different: it's
signed (positive upwelling, negative downwelling) around a real physical
zero (no vertical motion), with an absolute scale grounded in actual
research from an earlier round (5-10 m/day as typical). Applying the
identical area-relative treatment means a mildly-upwelling area could now
show 5 stars for a physically modest signal, or a genuinely strong
upwelling zone could show low stars simply for not being the most extreme
cell in that specific box. Implemented exactly as requested — "a similar
approach as structure scoring" for all five named signals including
upwelling — but that consequence was surfaced directly rather than left
to be discovered later as a confusing result. The flat-area case for
upwelling specifically uses neutral 0.5 (not the low 0.15 the other five
use), since "no meaningful vertical-motion variation" genuinely means
neutral for a signed measure, not "unfavorable" the way it does for an
unsigned one.

**Upwelling also gained neighborhood decay**, not just area-relative
scoring — structure's full treatment has two parts (area-relative basis,
and considering what's nearby, not just the exact pixel), and "a similar
approach as structure scoring" was read as both, not only the relative-
scoring half. Reverses upwelling's earlier point-exact design the same
way structure's was reversed last round. Verified directly: a cell near a
cyclonic (upwelling-favorable) wind center scores 0.13, while an
otherwise-identical cell farther away scores 0.02 — credit that fades
with distance now, where before only the exact pixel counted.

**A real, pre-existing test flaw was found and fixed while verifying
this**, not glossed over. The depth-floor regression test failed after
this change — not because the depth floor itself broke, but because its
own mock bathymetry had always let the "shallow shelf" zone's deepest
edge reach 55m, which is actually past the 37m floor, not under it as an
old comment claimed. The previous, less distance-sensitive structure
scoring never happened to promote a cell from that borderline zone into
the results, so the flaw stayed invisible until now. Fixed by making the
test's own shallow zone stay unambiguously shallow throughout (capped at
30m), and by validating against the real, computed depth at each result
rather than an arbitrary longitude marker — the actual criterion the
product enforces, not a proxy for it.

## Water Temperature and Current removed; Feature Intersection's radius explained; Structure redesigned

**Water Temperature and Current: genuinely removed, not hidden.** Direct
request. Both were point-exact "absolute value" signals (temperature
preference match, absolute current speed) — deleted entirely: the star
rows, the underlying scoring functions (`tempPreferenceScore`,
`TEMP_RANGE_C`), and their weight in the core formula. That weight
(0.2125 combined) was redistributed proportionally across the 7 remaining
signals, preserving their relative balance against each other exactly —
verified to sum to exactly 1.0, not eyeballed. Current break (the shear
signal) is unaffected and still fully present; only the plain absolute-
speed measure is gone.

**Feature Intersection's radius, answered precisely**: it doesn't have
one of its own — it inherits the same 5-mile neighborhood search each
individual signal already uses. Two contributing peaks can sit up to
~10 miles apart in principle (5 each, from opposite sides of a shared
evaluation cell), though weaker signals need to be considerably closer
in practice, since strength decays with distance rather than just being a
hard cutoff.

**Structure: reworked from a fixed global threshold to two direct
requests.** First — establish the analyzed area's own basis for relief,
then rate each cell by how extreme it is relative to THAT basis, not one
universal 20-600m threshold applied everywhere. A rugged canyon zone and
a naturally flat sand-bottom zone no longer share the same bar for what
counts as "extreme." Verified directly, not just reasoned about: the
identical 100m relief magnitude scores 0.11 when the surrounding area's
own range is 50-500m, and 1.00 when the area's range is only 5-100m — the
same number, genuinely different ratings, because what's remarkable
depends on the area. A safeguard was built in for the edge case: a
truly uniform area (near-zero variation anywhere) doesn't have its own
noise artificially stretched into a false "5-star extreme" rating —
below a 10-meter span, the whole area gets a uniformly low, honest score
instead, confirmed directly to land at that low value rather than being
inflated.

Second — relief now considers what's nearby, not just the exact pixel,
reversing an earlier design decision (structure had deliberately stayed
point-exact, on the reasoning that a ledge is "inherently located where
it is"). That reasoning no longer holds against the direct request here:
extended the exact same neighborhood-decay search already used for SST
break, chlorophyll edge, eddy, and current break — same 5-mile radius,
same linear falloff, no new radius invented. Verified end to end: a cell
2-3 miles from a sharp 500m wall scores 0.59, while an otherwise-identical
cell more than 5 miles away scores 0 — meaningful credit that fades with
distance, not a hard pixel boundary.

A real bug was caught and fixed while wiring this in, the same kind of
audit this project has relied on throughout: after restructuring
structure's scoring into two passes, three places downstream — the core
formula, the response's structure component, and its displayed relief-
in-feet detail — were still pointing at the old, no-longer-existent
point-exact field. Caught by a systematic search for every remaining
reference to the old field name before considering the change complete,
not left to surface later as a silent, wrong number.

## A critical, blocking bug found and fixed, plus three requested changes

**The bug first, since it took priority over everything else**: while
starting on the species-removal request, direct testing revealed the
forecast was completely non-functional — every single request failed
with `isBottomSpecies is not defined`. Tracing it back, an earlier partial
edit had removed the multi-species weight tables and the species-branching
logic that referenced them, but left several call sites still pointing at
now-nonexistent variables (`isBottomSpecies`, `coreWeights`,
`BOTTOM_SPECIES`). The single-species mahi weight table itself
(`CORE_WEIGHTS`) was already correctly in place — verified by
independently recomputing what its values should be from first principles
and finding them to match exactly — so the actual fix was narrow: remove
the dead bottom-species branches that could never run again (mahi is
never a bottom species) and point the remaining references at the real
constant. Confirmed by direct testing, not assumed: the handler failed
before this fix and succeeded after it.

**Local Grounds now unconditional.** Direct request: always part of every
forecast, with the star rating itself scaling continuously with proximity
— not gated on the area happening to include a documented ground.
Verified directly: distance from the Islamorada Hump at 0/1/3/6/10/20
miles produces influence scores of 1.0/0.97/0.78/0.37/0.06/0, a smooth,
monotonic falloff, confirming "closer = more stars" genuinely holds
rather than just being asserted in a comment.

**Species selection removed entirely.** Every forecast now runs with
mahi's settings, unconditionally — the species picker pillbox, its panel,
and the `&species=` request parameter are all gone from the client; the
server never reads or checks a species parameter at all. Two dead
UI blocks that depended on removed server fields were cleaned up in the
same pass: a "Tuned for" context line that looked up a species label
table which no longer exists (now just says "Mahi" directly), and a
"regional knowledge note" banner whose data source (a detailed region
object) was removed along with the region system — its information is
already covered by the per-spot Local Grounds star rating, just not
duplicated in a second, now-broken location.

**Legend shrunk, and a real layout risk fixed alongside it.** Investigated
thoroughly, not guessed: `.legend-gauge` and `.wc-enhance-btn` (the
water-color-contrast toggle, shown only on the True Color page) were
positioned at the exact same coordinates in the CSS. They don't currently
collide in practice — the app hides the legend whenever that button is
shown — but that's a fragile coincidence of the current page-switching
logic, not a structural guarantee, and worth fixing regardless of whether
it's visibly manifesting today. The button now sits below the legend's
own footprint instead of on top of it, which holds regardless of that
logic. The legend itself is meaningfully smaller — width and internal
gauge height both reduced by roughly a fifth, with its percentage-based
tick-mark positions adapting automatically since they're relative, not
fixed pixels. No other genuine overlap turned up in a systematic sweep of
every positioned map control (zoom, layer toggle, FABs, banners) — if
something still visibly overlaps after this, it isn't one of the cases
this investigation could locate in the code, and is worth a direct,
specific report (which button, which page) so it can be found precisely
rather than searched for blindly again.

## A real delivery bug, and local fishing grounds restored without bringing regions back

**The bug first, named plainly**: the region-picker UI and preset zone
boxes were still showing up after they were supposedly removed, because
`/mnt/user-data/outputs/index.html` — a standalone copy of the file kept
alongside the zip since early in this project — was never re-synced after
that round's changes. The zip itself was correct the whole time; the
standalone file sitting next to it wasn't. Fixed by re-copying it, and by
actually checking this time rather than assuming a prior sync held.

**The substantive request**: keep the documented-grounds knowledge, but
none of the region machinery it used to be locked behind — direct
follow-up after the full region removal. The two are genuinely separable:
the FIFR zones, region picker, and custom-region builder were all about
WHICH AREA gets analyzed; the grounds data itself is just real, named
places (the Islamorada Hump, the Rock Pile off Cape Hatteras, documented
wrecks and reefs) with their own coordinates, worth checking against
whatever area is being analyzed regardless of how that area was chosen.

**Recovered, not reconstructed from memory**: the original researched
grounds data still existed in `regional-knowledge.js` copies left in
`/home/claude/` and `/mnt/user-data/outputs/` — only the copy inside the
packaged functions directory had been deleted. All 12 named, real grounds
(5 off Cape Hatteras, 5 in the Florida Keys, one each off Sarasota and
the Treasure Coast) carried over with their original sourcing intact,
verified identical between the two recovered copies before trusting
either.

**Rebuilt as `fishing-grounds.js`** — deliberately renamed from
`regional-knowledge.js`, since nothing "regional" survives in it anymore:
a flat list of grounds, checked directly against a cell's coordinates,
with no region lookup, no region parameter, nothing to auto-detect or
select. One direct, worth-naming consequence of dropping the region
concept: Hatteras's 5 grounds were previously locked behind an explicit,
disabled region selection nobody could actually reach — they're included
here like everything else, so they now simply apply on their own if an
analyzed area happens to be near Cape Hatteras.

**Deliberately narrower than the original restoration would have been**:
only grounds came back, not the seasonal calendar ("Season") that used to
travel alongside it in the same region bundles — the request specifically
named "local fishing grounds," and Season wasn't mentioned, so it stayed
out rather than being restored on an assumption.

**A genuine design question, resolved by reading the request literally**:
should "Local Grounds" always show (even at 0 stars, the original
behavior when a region was always resolved to something), or only when
the analyzed area actually comes near a documented ground? "Consider it
if the area selected includes local fishing grounds" reads as
conditional, not "always present" — so it's now gated on the analyzed
grid actually containing a cell within meaningful range of a real ground,
computed directly from the same flat check every cell already runs, not
guessed at separately.

**Verified two ways**: a request centered on the Islamorada Hump showed
the grounds bonus applying correctly and "Local Grounds" appearing in the
star ratings; an identically-shaped request over open mid-Atlantic water,
nowhere near any documented ground, showed neither — confirming the gate
works in both directions, not just the positive case. Both checks re-run
against the actual packaged archive, not just the working copy.

## The entire region system removed — forecasts always run for the current map view

Direct request, confirmed to mean the whole system: not just the built-in
FIFR zones that auto-snapped the analyzed area, but also saved custom
(AI-built) regions and the region picker itself. Confirmed explicitly
before touching anything, since these are genuinely distinct sub-systems
— removing the wrong scope would have either destroyed saved custom
regions or left dead UI behind.

**What's gone**: FIFR zone auto-detection (server and client), the
75-mile "nearby zone" snap, custom region creation/building/storage (both
the client-side list and the server-side Netlify Blobs storage), the
entire region picker panel and "Add custom region" flow, the `&region=`
request parameter, and the two Netlify functions that existed solely to
support custom-region building (`build-region-background.js`,
`region-status.js`) — deleted outright, not just disabled, since nothing
calls them anymore. `regional-knowledge.js` is deleted too — nothing
requires it once no code path can ever set a region. Its only external
dependency, `@netlify/blobs`, is gone from `package.json` (which no
longer exists — no function in this project depends on any external
package now), and `netlify.toml`'s explicit `npm install` build step was
removed as a result.

**What replaced it**: the forecast always analyzes the current map
viewport, capped at 50x50 miles if the view is larger than that (zoomed
out further than the cap just shrinks the analyzed box back down, kept
centered on wherever the view is centered) — the exact 50x50 cap that
already existed in the code, previously bypassed whenever a FIFR zone
applied, now applies unconditionally with nothing left to bypass it.

**A real, non-obvious consequence, surfaced directly rather than left
silent**: two inputs — "Local Grounds" and "Season" — depended entirely
on the region system for their underlying data (documented productive
grounds, seasonal strength curves, both compiled per-region). With no
region ever resolved now, both are gone from the star ratings entirely,
not just hidden — there's no other source they could pull from. The
scoring formula itself was simplified to match: the zone-proximity bonus
and seasonal multiplier terms were removed from the final score
calculation rather than left in as permanently-neutral dead weight.

**Verified two ways**: a request centered exactly on where the old
"Florida Keys" zone used to be confirmed the analyzed area now matches
the request exactly, with no snapping — proving the override is
genuinely gone, not just harder to trigger. And a deliberately oversized
(~200x330 mile) request confirmed the 50x50 cap still applies correctly,
centered on the request's own center point. Every other scoring mechanism
in this project — the land mask, depth floor, neighborhood convergence,
persistence, current break, Ekman upwelling — was re-verified afterward
and passes unchanged, confirming the removal touched only what it was
supposed to touch. Performance improved slightly too (the region
resolution step included a Netlify Blobs lookup on every request that no
longer exists).

## "Current" was never a break — a real gap found from a precise question

Direct question, answered by reading the code rather than from memory:
current has only ever measured absolute speed (nearestValue on the u/v
components, then magnitude), never a break. Confirmed by direct
comparison — SST, chlorophyll, and eddy all use `gradientAt`, a genuine
gradient/edge calculation; current used `nearestValue` alone. This is a
real gap, not just a naming one: the very first framing of the four
convergence signals explicitly said "current break," and what actually
got built was current SPEED.

**Fixed with a genuine vector-shear signal**, not a scalar patch. A
scalar speed gradient would miss a real, common case: two currents
converging at different ANGLES with similar speeds still creates a
genuine shear line — visible current edges, rip lines, where debris and
bait concentrate — and speed alone wouldn't show it. `currentShearAt` is
the vector analog of `gradientAt`: it measures the magnitude of the
VECTOR difference between a cell's current and each neighbor's, not just
the difference in speed. Verified directly before trusting it, in
isolation first: a test case with identical speed but opposite direction
on either side of a boundary registered a strong break (1.0 m/s vector
difference), while a uniform-flow sanity check correctly showed zero.

**The existing absolute-speed signal was kept, not discarded** — strong
current is still genuinely useful information on its own, independent of
whether there's a sharp edge nearby. It's simply reclassified to match
how temperature preference already works: point-exact, not part of the
neighborhood-convergence search, since "is the water moving fast enough
here" is about actual local conditions, not proximity to an edge. Each
species' existing current-related weight was split 60/40 between the new
break signal and the kept favorability signal — same total budget as
before, verified directly that every species' weights still sum to 1.0.
"Current" and "Current break" now show as two separate star ratings, so
this distinction is visible going forward without needing to ask again.

**Verified through the full pipeline, not just the isolated function**: a
test built specifically around the case a speed-only measure would miss
— equal speed, opposite direction, meeting at a boundary — showed
`currBreak` clearly notable (0.69) while `currFavor` (the speed itself)
stayed unremarkable (0.24), confirming the two signals genuinely measure
different things rather than one just being a relabeled copy of the
other. Full regression suite — FIFR zones, the land mask, the depth
floor, neighborhood convergence, persistence, SST resilience — still
passes.

## "Depends on which page is open" — traced to a genuine caching gap, not a page-dependent bug in the logic

Reported directly: SST Break only showing with the SST composite page
open, and forecast points landing on shore only when it wasn't. Read as
literally as possible — since `currentPage` is a purely client-side,
visual concept, and the forecast is supposed to be an independent
computation over a geographic area, it should be structurally impossible
for it to matter at all.

**Traced exhaustively before writing any fix**, not assumed: every single
reference to `currentPage` in the entire client was found and checked —
all of them govern which visual tile layer to display (SST/chlorophyll/
altimetry/true color), none of them touch the forecast request, its
response handling, or how spot markers get rendered. The request URL
itself depends only on the map's bounding box, species, and region —
confirmed directly by reading `runForecast` and
`computeCappedForecastBounds` — never on which page is active. The
scoring logic itself, all the way through this project's recent
restructuring, is confirmed genuinely independent of it.

**What was actually missing**: the forecast response had no
`Cache-Control` header at all. For data that represents live, changing
ocean conditions — SST and chlorophyll availability genuinely varies
minute to minute, as this whole project has repeatedly confirmed — that's
a real gap, not a hypothetical one. Without an explicit directive, a
browser is free to serve a stale, cached response for an identical
bounding box. That gives a concrete, unifying explanation for BOTH
symptoms landing together: a single stale response, frozen from a moment
when SST or bathymetry (or both) happened to be unavailable, would show
exactly this — no SST Break (the source was down when that response was
captured) and an unmasked land point (the land mask never got the
bathymetry it needed either). Switching pages often coincides with
panning or zooming the map, which changes the bounding box and
incidentally busts a stale cache entry — which could look like a
page-dependent effect while never actually being caused by the page
itself.

**Fixed on both sides**: the server now sends `Cache-Control: no-store`
explicitly, and the client's own fetch call adds `cache: 'no-store'` to
match — belt and suspenders, since relying on server headers alone can be
inconsistently honored. Verified directly, not just added on faith: the
actual response headers from a live handler call now show the directive
present.

**Named plainly**: this fix is well-reasoned and directly explains the
mechanism far better than a page-dependent bug in the scoring ever could
have (since exhaustive tracing found no such dependency to fix) — but it
can't be verified with full certainty from this environment, the same
honest limit as the diagnostic-driven fixes earlier in this project. If
results still ever seem to depend on which page happens to be open after
this, that's the next thing to report — and the diagnostics already built
into `sources.sstLog`/`sources.sstHistoryLog` remain the most direct way
to see, as fact, what a specific request actually returned.

## Three direct corrections: depth as reference, chlorophyll favorability added, persistence corrected to neighbor-based

**Depth, as reference only, explicitly NOT a scoring input.** A plain
lookup against the same bathymetry already fetched for the land mask and
structure scoring, computed only for the final ~5 top spots (not all 324
scoring cells, since it's purely informational) and attached after
scoring is already complete — there's no path from this value back into
score, `zoneBonus`, or anything else in the formula. Shown next to
coordinates in both the map popup and the panel list, not folded into the
star ratings list, since it was never assigned a star score to begin
with.

**Chlorophyll: a second, genuinely distinct signal added, not a
replacement.** The existing "Chlorophyll edge" gradient detector is
unchanged. New alongside it: whether the ABSOLUTE concentration itself is
favorable — "is the water here plankton-rich enough," not "is there a
transition nearby." Grounded in real research rather than guessed:
multiple independent studies on tuna/pelagic catch rates converge on
roughly 0.15-1.0 mg/m³ as productive (cited directly: Gulf of
Bone-Flores skipjack hotspots 0.15-0.35; Sri Lankan yellowfin
aggregations 0.3-0.4; Ternate Island skipjack >0.2-0.35), with a
mahi-specific source separately confirming that species tolerates a much
wider 0.01-5.0 range and cares more about the edge than the absolute
level — consistent with keeping this a secondary signal, not the
dominant one. Point-exact, like temperature preference, not neighborhood-
aware like the edge detector: favorability is about actual local
conditions, not proximity to a feature elsewhere. Each species' existing
chlorophyll-related weight was split 60/40 between the edge (unchanged)
and this new favorability signal, so the total chlorophyll-related weight
budget per species is exactly what it was before — verified directly,
not just reasoned about, that every species' weights still sum to 1.0
after the split.

**Persistence, corrected: evaluated as a neighbor, not pixel-by-pixel.**
Direct correction to a design choice from the prior response, and the
prior reasoning was wrong: requiring the identical exact coordinate to
have shown a notable front on a prior day misses the ordinary case where
a real front drifts a mile or two day to day — still plainly the same
feature, just not sitting on the exact same pixel. Restructured so each
historical day is searched across the same neighborhood radius used for
today's four convergence signals, extending the same search loop rather
than duplicating it. Today's side of the day-to-day trend comparison was
made consistent with this too — both sides of "has this front held
position" now use neighborhood-aware data, rather than mixing a
neighborhood "today" against a pixel-exact "history."

**Verified against the specific case that would have broken under the
old design**: a front at one location today, with a front at a
DIFFERENT location roughly two miles away on the two prior days —
simulating a drift, not a new feature. The winning spot's own exact
coordinates fall in neither location, so under the old pixel-exact
logic, `persistenceDays` at that spot would have been unambiguously 0.
Confirmed directly: persistence and rate-of-change both correctly
recognize the drifted front now.

**A bug caught during this rewrite, worth naming rather than glossing
over**: extracting persistence out of pass 1 into pass 2 initially left
two stale references — the final score formula and the response's
detail fields both still pointed at fields that no longer existed after
the restructuring, which would have produced silent `NaN` scores. Caught
by a deliberate, systematic audit of every remaining reference to the
old field names before considering the change complete, not by a test
happening to catch it after the fact.

Full regression suite — FIFR zones, the land mask, the depth floor,
neighborhood convergence, SST resilience, persistence — still passes,
and the added historical-day search (up to 3x the existing O(N²)
neighborhood cost) stayed comfortably within the time budget across
repeated runs.

## Land mask — forecast points were landing on shore, a side effect of SST finally working

Reported immediately after the SST fixes: forecast points appearing on
land. The cause is a direct consequence of the fix that preceded it, worth
stating plainly: the scoring grid always covered each zone's full bounding
box, and every FIFR zone's box includes coastline — so cells with centers
on land were ALWAYS being scored. It just never mattered while SST was
broken, because nothing made those cells stand out. The moment SST started
working, the land-sea boundary became the sharpest apparent "gradient" on
the map (ocean pixels simply stop at the coast, so the nearest-value
transition reads as an enormous break), and coastal/land cells started
winning top-spot rankings on the strength of an artifact.

Fixed with a land mask at the very top of the scoring loop: GEBCO
bathymetry covers land as well as seafloor (positive elevation = above sea
level), so its value at each cell center is a direct land test using data
already fetched for structure scoring. Cells at or above sea level are
skipped before any scoring work — they cannot be fishing spots regardless
of what any other signal says. When bathymetry is unavailable, no mask is
applied (no guessing without data), and the response now carries
`landCellsExcluded` for transparency.

Verified against the exact reported failure shape: a coastal bounding box
whose western 40% is land, with a deliberately screaming SST gradient
along the shoreline. Before-the-mask behavior would have put top spots on
the beach; with it, 180 land cells were excluded and every top spot landed
in the water. Test mocks that generated physically impossible positive
"ocean" elevations were corrected to negative (underwater) values —
without that, the mask would have correctly classified every mocked cell
as land, which is the mask working, not failing.

## RESOLVED via live diagnostics — three distinct real causes, finally observed instead of guessed

After many rounds of fixes that never moved the result, the honest turning
point was recognizing that the unchanging output was itself the signal: I
was reasoning about what the servers did rather than observing it, because
this build environment has no network access to the NOAA endpoints. The
fix wasn't a different language (a question that came up, and the answer is
no — the language was never the constraint; the lack of live network access
was). It was a purpose-built diagnostic function (`diag.js`) that runs from
the *deployed* environment, which CAN reach the endpoints, probing every
SST-family source two ways — a minimal reachability check and the exact
query the forecast builds — alongside known-working sources as a baseline.

That one diagnostic run, pasted back from the live site, revealed three
genuinely distinct problems that no amount of further guessing would have
separated — each now confirmed as fact, not hypothesis:

1. Hourly (GOES-19): a real bug in the query — the `(last)` fix applied to
ACSPO/MUR but missed here. The minimal hourly query returned live data
(200, hundreds of points) while the forecast-shaped query returned a 404
whose body stated it exactly: Stop greater than the axis maximum. The
hourly range still ended at a computed "now," which overshoots the
dataset's newest timestamp by hours, and ERDDAP rejects the entire request
when the stop bound exceeds the axis maximum. Fixed by ending the hourly
range at `(last)` too — the same one-line fix already on the other tiers,
simply missed here, and that miss alone took out the whole hourly tier.

2. ACSPO and the old chlorophyll dataset: HTTP 403 Forbidden — not our bug,
not fixable in code. Both returned 403 Forbidden on every query shape,
while currents, altimetry, and GEBCO returned 200 in the same run from the
same environment — proving a dataset-specific access restriction, not a
server, network, or query problem. ACSPO's metadata independently showed
data frozen since January 2025. Both were retired rather than "fixed": no
code grants access a server refuses, and ACSPO had no recent data anyway.
ACSPO's removal is safe because MUR covers the same need — proven by the
same diagnostic. Chlorophyll was moved to NOAA's S-NPP VIIRS Global 4km
daily product on the coastwatch server (same chlor_a variable, ~0.0375
resolution, current date_created), included in diag.js for live
confirmation.

3. MUR: fully working, now the backbone. With ACSPO gone, hourly (fixed) is
the primary SST source and MUR the fallback; for the history feeding
persistence/rate-of-change, MUR is now the sole source (its range query
returns multiple distinct days on its own).

Why this took as long as it did, stated plainly: the earlier rounds each
found and fixed genuine defects (striding, the timeout cascade, the
concurrency dependency, the downsampling regression) — but every one was
downstream of causes #1 and #2, which could only be seen by observing the
live endpoints. Once the diagnostic replaced speculation with actual HTTP
responses, all three causes were identifiable in a single pass. The lesson
worth keeping: when repeated fixes don't move a result, stop assuming the
next fix is the answer and build the instrument that lets you observe the
failing system directly.

Confirming it: redeploy, open /.netlify/functions/diag once more; the
expected picture is hourly/nowFixed OK, mur/* OK, at least one chlNew/* OK,
the old acspo/* and chl/oldForbidden still 403 (harmless — retired), and
baselines OK. The full regression suite passes; stale test mocks that
assumed the old datasets were updated to match reality.


## Time ranges ending "today" against datasets that run days behind — found in live metadata

The eighth report, still the identical list. At this point the most
important realization was about method, not code: nothing changed by
editing code was moving the result, which is itself the signal. So this
round started by ruling out, concretely, the possibility that the code
wasn't the deciding factor at all — confirmed the deployment config is
correct, confirmed the client genuinely renders whatever the function
returns with no mock or fallback path, and confirmed (by reading it
directly, finally) that the star-rating gating logic keys each input off
its own source flag correctly. All sound. The missing inputs really are
absent from the server's actual output.

Then the narrowing that mattered: altimetry and currents run against the
*same* `cwcgom.aoml.noaa.gov` ERDDAP server as the failing SST composite,
and they work — which definitively rules out the server, ERDDAP itself,
and network access, none of which this investigation had actually
eliminated before rather than assumed. What's genuinely unique to the
entire failing set (all SST tiers, the history fetch, and — no) is the
time dimension: they use multi-day time-RANGE queries; every working
source uses a single time step.

**The confirmed fact**, read directly from MUR's live ERDDAP metadata,
not inferred: `time_coverage_end` is several days behind the current
date (the dataset documents itself as "created at nominal 4-day
latency"), and its daily time points land at 09:00:00Z, not midnight.
Every one of these range queries used a date-only "today" as its stop
bound — which asks for a window ending days past the newest data that
exists, starting from a midnight boundary the data doesn't sit on.
Depending on how ERDDAP handles an out-of-range stop bound, that can
yield an error or an empty result rather than clipping cleanly to
available data.

**The fix**: every one of these range queries now ends at `(last)` —
ERDDAP's own token for "the newest actual value" — instead of a computed
"today." That's guaranteed in-range by construction, removing all
dependence on how ERDDAP treats a future-dated bound. Applied to all four
places it occurs: the ACSPO and MUR composite tiers, and the ACSPO and
MUR history fetches (the latter being what feeds Persistence and Rate of
Change specifically).

**Scrupulous honesty about what this is**, given how many rounds this has
taken: the latency is a confirmed fact, and ending a range past a
dataset's newest data is unambiguously wrong to do — so this fixes a real
defect regardless. But whether it's *the* defect behind the reports can't
be fully verified from here, because that would require a live request
against these endpoints from the deployed environment, which this
sandbox can't make. What can be said: it's the first hypothesis in
several rounds grounded in a specific, confirmed fact about the live data
(not reasoning about payloads or timing), it targets exactly the query
form that distinguishes every failing input from every working one, and
the full regression suite still passes with it in place.

**On testing discipline, stated plainly**: every regression this change
first appeared to cause turned out to be a stale *test mock* that didn't
recognize the `(last)` token — not a code failure. Those were fixed (the
mocks' own URL parsers upgraded to match), and the point is noted here
rather than buried: the mocks encode assumptions about the exact query
strings, so changing a query legitimately requires updating them, and
each was verified to be a mock artifact rather than waved away.

**If this still doesn't resolve it**: the per-source, per-reason
diagnostics added in prior rounds (`sources.sstLog`,
`sources.sstHistoryLog`, now carrying the actual HTTP status or error for
every failed tier) are the intended next step — read directly from the
raw response for the specific failing location, they distinguish a 404
from a timeout from an empty-but-successful return, which finally
separates "still a bug" from "genuinely no data there right now" without
another round of hypothesizing.

## Missing/patchy data handling — the distance-cutoff fix

Raised directly: how does the forecast handle a source being unavailable,
like SST behind several days of cloud cover? Two distinct cases, handled
differently.

**Total unavailability** was already handled correctly: `sources.sst` (and
each other source) is set by checking whether any usable pixels actually
came back, not just whether the HTTP request succeeded — so a fetch that
returns 200 OK but every pixel clouded over still correctly reports that
source as unavailable, falls back to a neutral score contribution, and
omits it from both the source chips and each spot's factors breakdown.

**Patchy/partial cover was a real, previously-unflagged gap**, now fixed.
`nearestValue()` — the function that finds the closest real reading to a
given grid cell — had no maximum-distance cutoff. It would always return
the closest valid pixel it could find, no matter how far away, meaning a
zone that's 80% clouded with one clear corner would have every cell in
that 80% silently borrow the corner's reading as if it were local. Fixed
two ways together:

- **Distance is now real miles**, not a raw sum of degrees (the old
  metric wasn't even proportional to real distance once you're far
  enough from the equator for longitude compression to matter).
- **Each of the six sources (SST, chlorophyll, altimetry, current u/v,
  bathymetry) gets its own self-scaling cutoff** — 2.5x that specific
  map's own typical point spacing this run, computed fresh per request.
  A naturally coarse source (altimetry, currents) gets a proportionally
  larger allowed radius than a naturally dense one (SST, chlorophyll),
  and a heavily-clouded run gets a tighter effective radius than a
  clear-sky one, since the map itself is sparser. A cell beyond that
  radius gets `null` back — treated as no local data for that one
  signal, falling back to the neutral default — rather than a distant
  reading presented as if it applied here.

Tested directly with a simulated heavy-cloud-cover scenario (real SST data
in only a small corner of a zone, everything else normal): of 308 cells
outside that corner, only 3 borderline ones (right at the edge of the
test's own comparison boundary) still picked up an SST reading — before
this fix, all 308 would have.

### A separate performance issue this surfaced (not caused by the fix itself)

Benchmarking the distance cutoff under a realistic worst case — the
largest FIFR zone (Panhandle), fully dense data on all six sources, a
clear-sky day rather than a rare edge case — turned up the scoring loop
alone taking **6.3 seconds**, out of the function's 8,500ms total budget.
Confirmed this wasn't something the distance-cutoff change introduced: the
*old* distance formula was measured at the identical scale and was
equally slow (3.81s vs. 3.93s — noise-level difference). The real cause
had been sitting in the code already: the same `"lat,lon"` string keys
were being re-parsed from scratch on every one of roughly 7,000
`nearestValue` lookups per request, each scanning up to 1,600 points.

Fixed by pre-parsing each source's data into a plain numeric array once,
right after downsampling, instead of re-parsing the same string keys
redundantly on every lookup against that same map. Measured directly:
6.3s down to about 0.9s for the identical worst-case scenario — roughly a
7x improvement, and a meaningful reduction in timeout risk given this
project's history with exactly that failure mode. Fixed proactively
rather than just flagged, given how seriously this app has treated
timeout risk throughout, though it's worth knowing it went beyond what
was specifically asked for.



## Scoring weights — mahi and the four modulators (user-specified)

The mahi core weights and all four modulator ranges reflect specific
values requested directly, not the original design judgment described
earlier in this document. Documenting exactly what changed and why, since
a couple of details needed a decision on the way in.

**Mahi core weights** — requested as SST break 0.28, water temp 0.18,
chlorophyll 0.20, eddy/SSH 0.15, current 0.10, bathymetry 0.04. These sum
to 0.95, not 1.0. Left unnormalized, `weightedGeoMean` (which computes
`Π score_i^weight_i` with no division by the weight total) would still
run without error, but a weight-sum below 1 mathematically inflates the
geometric mean — more at the low end than the high end, since raising a
fraction to a power under 1 pushes it toward 1, and does so more
aggressively the closer that fraction already is to 0. The practical
effect would have been every mahi score reading slightly higher than it
should, and the system being slightly less able to distinguish a bad spot
from a mediocre one. Normalized instead, preserving the exact requested
*proportions*: `{ temp: 0.189, sstGrad: 0.295, chlGrad: 0.211, eddy:
0.158, curr: 0.105, struct: 0.042 }` — each is the original value divided
by 0.95, summing to exactly 1.0.

One real consequence worth knowing: temperature's weight dropped from
0.28 to 0.189, so a badly-out-of-range temperature now drags a mahi
score down less than it used to (tested directly: a cell with great
everything *except* temperature went from scoring 0.52 under the old
weights to 0.65 under the new ones). That's an inherent, correct result
of shifting emphasis toward the SST break and chlorophyll — not a bug,
just worth being aware temperature mismatches are now a comparatively
smaller factor than before.

**Modulators — all four are global**, not mahi-specific: zone bonus,
weather, moon, and season are computed once per request and applied to
every species (tuna, wahoo, sailfish, snapper, grouper too), since the
current architecture doesn't have per-species modulator ranges. Flagging
this rather than silently scoping the change to mahi only, since
restructuring for per-species modulators would be a materially bigger
change than what seemed intended.

- **Zone bonus: 0.9x–1.2x** (was 1.0x–1.25x). This is a real principle
  change, not just a range tweak: the original design *never* penalized
  distance from a documented ground — "fish are caught away from famous
  spots all the time" — so it only ever boosted, floor 1.0x. The new
  range means a location with no documented ground nearby now scores 10%
  *lower* than the live-conditions score alone would suggest. Implemented
  as requested; worth knowing it's a philosophy reversal, not a
  continuation of the old one at different numbers.
- **Area-wide (weather) modulator: 0.9x–1.1x** (was 0.85x–1.15x) — a
  tighter range, weather swings the score less than before.
- **Moon modulator: 0.97x–1.03x** (was 0.9x–1.1x) — much tighter; moon
  phase now barely moves the needle.
- **Season multiplier: 0.5x–1.2x** (was 0.6x–1.1x) — a wider range in
  both directions; being badly out of season now dampens more, and being
  at peak season boosts more, than before.

**Gulf Stream removed from the named-grounds list.** Two zone entries —
"the Gulf Stream edge" (Hatteras) and "the Gulf Stream off Sebastian"
(Treasure Coast) — were deleted rather than just left alone. The
reasoning behind this is sound and worth keeping in mind for any future
zone additions: the Gulf Stream meanders day to day, so a fixed lat/lon
"Gulf Stream" bonus zone could easily be pointing at the wrong place on
any given day, while the live SST break, chlorophyll edge, eddy signal,
and current speed factors already in the core score will correctly find
wherever the Stream actually is *today*, not where it usually is. A
judgment call on scope: "Cape Point convergence" (Hatteras) was *not*
removed, even though the Gulf Stream is one of the two currents involved
— it's framed and named around a distinct, more specific phenomenon (a
convergence near a fixed cape), not "the Gulf Stream" as a location in
itself, so it seemed like a different case. Worth double-checking that
reasoning if it doesn't match the intent.

One further consequence: Treasure Coast's mahi/tuna/wahoo/sailfish now
have *no* named grounds left at all (the Gulf Stream entry was the only
one tagged for those species there) — meaning, combined with the zone
bonus change above, every pelagic forecast in that zone now carries a
flat 0.9x zone penalty with nothing to offset it. That may be exactly
right (no other real named ground was found there in the original
research), but it's a direct, compounding result of both changes
together, not something to assume is fine without checking.

## Star ratings — replaced the prose narrative entirely (direct request)

The prose narrative and its companion factors breakdown are both gone,
replaced by a 0-5 star rating (0.5-point increments — 11 possible values
per input) for every input actually considered for that spot's score.
`toStars(score) = Math.round(clamp01(score) * 10) / 2` — verified directly
that all 11 increments are reachable and out-of-range inputs clamp
correctly (0 and 5 respectively) before relying on it anywhere.

**What gets rated, and why some inputs are missing sometimes:** an input
is omitted entirely rather than shown at a misleading neutral rating when
its source genuinely wasn't available this run — same honesty principle
the old factors breakdown already followed. Pelagic species (mahi, tuna,
wahoo, sailfish, general): Water Temperature, SST Break, Chlorophyll, Eddy
/ SSH, Current, Structure, Feature Intersection, Persistence, Rate of
Change (the last two only when the history fetch actually returned data),
Local Grounds (only when a region applies — shown even at 0 stars there,
since "not near any documented ground" is real information, not a missing
input), Wind, Pressure Trend, Moon Phase, Season. Bottom species (snapper,
grouper) use a different, shorter set matching what actually feeds their
score: Water Temperature, Structure, Tide, Local Grounds, Wind, Pressure
Trend, Moon Phase, Season — no SST break, chlorophyll, eddy, current,
feature intersection, or persistence, since none of those are part of
bottom-species scoring at all.

**Where a concrete number still exists, it's kept alongside the stars** —
each rating carries an optional `detail` string (actual °F, knots, feet,
the moon phase name, and so on) so the "what data was considered"
transparency the narrative used to provide isn't lost, just presented
differently. Rate of Change is the one rating that isn't a simple "how
good" score — it's directional (strengthening/steady/weakening), mapped
to stars matching the bonus/penalty already applied to the underlying
score (strengthening rates high, weakening rates low) rather than
literally converting a 0-1 magnitude.

**Verified directly, not assumed:** ran the same uniqueness check
previously used for the narrative — five top spots from one forecast
came back with 5/5 distinct star-rating signatures, not repeated
patterns. Also confirmed the different rating sets actually differ
correctly between a pelagic and a bottom species request, and that
Persistence/Rate of Change are correctly absent when the history fetch
comes back empty rather than showing a misleading 0-star rating for data
that was never actually checked.

**Client-side rendering** uses the standard CSS star-overlay technique — a
row of empty stars as a base layer, a row of filled stars absolutely
positioned on top and clipped to the exact percentage (e.g. 3.5/5 = 70%
width) — which handles any of the 11 possible values identically without
needing a separate half-star glyph. Shown in both the results panel and
the map popup, via one shared rendering function so the two stay
consistent by construction rather than by manual upkeep.

## AI-built custom regions — set a region, let an LLM research it once

Beyond the 9 Florida zones (and Hatteras, if re-enabled), you can add your own from the
app: open the Forecast panel, tap the region selector, and choose **"+ Add
custom region."** Type a name, and the app uses whatever area is currently
in view as that region's boundaries. This is deliberately **not** a call
on every forecast — it's a one-time (or periodic, if you rebuild it later)
background research pass, cached afterward and reused by every future
forecast in that region, which is the architecture actually requested and
what makes this workable at all without reintroducing the timeout risk
this project already fought hard to fix once.

### Priority order: custom region > Florida zone > explicit non-FIFR region

A custom region you've actually built and selected wins even over Florida
zone auto-detection, including for a custom region that happens to sit
inside one of the 9 zones' boundaries. This isn't arbitrary — it's a fix
for a real bug a regression test caught while building the zone system:
back when Hatteras was the client's default explicit-region value, the
client always sent *some* region value whether or not anyone had actually
chosen something, so treating any explicit value as an override would
have meant that bare default silently defeated Florida zone detection on
every single Florida request. The fix distinguishes a genuine choice from
a bare default: a custom region's ID is always prefixed `custom_` by the
app, so the function checks for that prefix specifically and only lets a
*real, deliberately built* custom region take priority. This still
matters even with Hatteras disabled and the client now defaulting to `''`
(empty, meaning "no override") instead — the same distinction is exactly
what makes an empty default correctly fall through to FIFR zone detection
rather than needing special-casing.

### What happens when you add one

1. The client calls `build-region-background.js` — a Netlify **Background
   Function** — with the region's name and bounding box, then immediately
   shows "Building…" in the picker and starts polling.
2. That function calls the Anthropic API with **web search enabled**,
   asking it to research real seasonal patterns and named fishing grounds
   for the area, in the same schema the hand-compiled regions use.
3. The result is validated thoroughly before being trusted — treated with
   the same skepticism as any other unverified external data source, not
   taken on faith just because an LLM produced it (see "Why the result is
   validated, not trusted" below).
4. If it passes, it's saved to **Netlify Blobs** under the region's ID.
   `forecast.js` checks there for any region ID it doesn't recognize from
   the hand-compiled set, so a validated custom region is used identically
   to Hatteras or the Keys from then on — no further LLM calls.
5. The client polls `region-status.js` every 5 seconds (capped at 5
   minutes) and updates the picker once the region is ready or failed.

### Setup required (this is real cost/commitment, not optional)

- **Netlify's Personal plan ($9/mo) or higher.** Background Functions —
  needed because a real web-search-enabled research call can take well
  beyond a normal function's timeout — aren't available on the free tier.
  Confirmed directly before building this, not assumed.
- **An `ANTHROPIC_API_KEY` environment variable**, set in Netlify's
  dashboard under Site configuration → Environment variables. Get a key at
  console.anthropic.com. Each region build costs a modest amount in API
  usage — once per region added, not per forecast.
- **`@netlify/blobs` as a dependency** — already added to
  `netlify/functions/package.json`, with an explicit `npm install` build
  step in `netlify.toml` to make sure it's actually installed rather than
  relying solely on Netlify's auto-detection for something this critical.

Without the API key set, a build attempt fails fast with a clear message
in the region's status ("ANTHROPIC_API_KEY is not set...") rather than
hanging — you'll see "Failed" in the picker, and can remove the attempt
and retry once the key is configured.

### Why the result is validated, not trusted

An LLM's structured output is still an unverified external input, so
`build-region-background.js` checks it the same way this whole project
checks any other external data before using it: every seasonal array must
be exactly 12 numbers between 0 and 1; every zone must have a name,
reasonable coordinates, a sane radius, and only recognized species; and —
this is the check that matters most — **a zone whose coordinates land
implausibly far from the requested region is rejected outright**, since
that's the signature of a hallucinated location rather than a real
research result. If validation fails, the region is marked "Failed" with
the specific reason, and nothing bad gets stored. This was tested directly
against seven deliberately-bad inputs (wrong array lengths, out-of-range
values, a hallucinated London coordinate for a Florida region, an
unrecognized species, missing fields) before shipping — all correctly
rejected.

### Honest limits

- **Quality depends on what the model can actually find.** The prompt
  explicitly asks it to report fewer, more honestly generic zones rather
  than invent specific-sounding names it isn't confident in, and to say so
  plainly in a `confidenceNote` shown in the app — but a custom region for
  an obscure or sparsely-documented spot will likely come back thinner
  than Hatteras or the Keys, the same way Sebastian Inlet did with human
  research.
- **This still isn't the same as live social-media monitoring** — it's a
  one-time research pass using whatever's publicly indexed at build time,
  not an ongoing feed of recent captain reports. The reasoning for why
  that's not built at all is above, in the original regional-knowledge
  section — it applies here too.
- **A region can be rebuilt** by removing it (the × on its picker item)
  and adding it again — there's no in-place "refresh" button yet, since
  the person asked for "once or maybe periodically," and rebuild-via-
  remove-and-readd covers the periodic case simply enough for now.


### A real bug: selecting a species broke SST

Found and fixed: the species picker reuses the same CSS class
(`.source-picker-item`) as the SST source picker (Composite/MUR/Hourly),
which was intentional for consistent styling. But two of SST's own click
handlers queried `.source-picker-item` globally across the whole page
instead of scoping to their own panel — so selecting a species also
matched those handlers, which read `data-mode` (species buttons only have
`data-species`), got `undefined`, and called `switchLayerMode(undefined)`,
breaking SST layer construction. Fixed by scoping both queries to the SST
panel specifically.

`forecast.js` fetches every data source in parallel, scores a grid of
locations for a target species, and returns ranked top spots — each with a
plain-language narrative — plus the full scored grid for a heat map.

### A real bug was found and fixed here

An earlier version had a genuine bug: the scoring grid's cell-center
coordinates were looked up directly in maps keyed by each data source's own
sample points. Those essentially never match exactly, so the lookup
silently returned nothing for nearly every cell, every component fell back
to a neutral default, and every location ended up with an identical
productivity score. Fixed with a shared nearest-match lookup used for both
the center point and its neighbors, and confirmed numerically afterward —
a synthetic grid with a real temperature front now correctly shows varied
scores (0.23–0.73 across cells in one test) instead of one flat number.

### Convergence, not averaging

Scoring was restructured around convergence as the organizing principle,
based on how this is actually done (researched directly — SST-chart
guides, the BDOutdoors piece on stacking temperature/chlorophyll/structure,
and an academic fishing-ground-prediction paper all independently confirm
this). The scores now combine with a **weighted geometric mean**, not a
weighted sum: any single near-zero signal collapses the result toward
zero, rather than being diluted into a moderate average by other decent
signals. Verified directly: a location strong on five signals but with the
wrong water temperature for the target species now scores 0.363 instead of
0.581 — genuinely penalized for not converging, not just nudged.

### Species temperature preference

A real gap in the original version: it scored temperature *break*
sharpness but never checked whether the water was even in the right range
for the target species. Added actual preferred ranges (research-backed —
mahi 72-78°F, tuna 70-82°F, wahoo a broad 64-82°F favoring the cooler side
of a break, sailfish 75-85°F), converted to Celsius and verified before
use. Wahoo specifically get a scoring bonus when a break's cooler side is
where they're sitting, a real, named detail from how wahoo relate to
temperature edges — not just generic break-sharpness scoring.

### A critical crash bug was found and fixed here (post-deploy)

The convergence rewrite above introduced a severe bug: a leftover
reference to `SPECIES_WEIGHTS`, a variable that no longer existed after
being renamed to `PELAGIC_CORE_WEIGHTS`/`BOTTOM_CORE_WEIGHTS` during that
same rewrite. This threw immediately on every single request, which is
why the forecast failed 100% of the time. Fixed — and because this exact
bug passed a syntax check (`node --check` only validates syntax, not
runtime behavior) and only surfaced at runtime, it was verified this time
by actually *executing* the handler with mocked network responses across
every species, including an invalid one, confirming it now runs
end-to-end without crashing and still produces varied, non-flat scores
(156 unique values across 324 cells in one test run). A top-level
try/catch was also added around the whole handler as a backstop, so a
future bug in this class produces a clear, diagnosable message instead of
a silent crash.

The heat-map grid overlay was also removed per feedback — the forecast
now shows only the numbered spot markers, not a colored grid underneath
them.

### A likely timeout cause was found and fixed here (post-deploy)

After that fix, the forecast started failing with a different, Safari-
specific error ("The string did not match the expected pattern") —
researched directly rather than guessed at, and confirmed to be WebKit's
generic error for calling `res.json()` on a non-JSON response, most
commonly an HTML error page returned when a server-side function is
killed for running too long.

The function's fetch structure was genuinely at risk of this: after the
first parallel batch, up to five more fetches ran one after another —
wind's forecast fetch, then pressure's two-hop station lookup, then tide
predictions, then bathymetry — each with its own timeout budget stacked on
top of the last. Restructured into three parallel rounds instead: round 1
is every fetch with no dependencies (bathymetry moved in here too, since
it never depended on anything else), round 2 is wind/pressure's first
hop/tide predictions running together instead of one after another, and
round 3 is the one fetch that genuinely can't happen earlier (pressure's
observation history, which needs the station ID round 2 just returned).

Verified by actually executing the handler with mocked network responses
and artificial per-fetch latency, not just reasoning about it — confirmed
wall-clock time dropped substantially versus a fully sequential simulation
of the old structure, and re-ran the full species sweep afterward to
confirm nothing broke in the process.

**That parallelization wasn't sufficient on its own** — the same error
persisted after deploying it. Rather than guess again at which specific
step was still too slow, added a hard overall time budget (8.5s) that the
whole function respects regardless of where time is actually being spent —
network latency on any source, or the scoring computation itself. Each
round's fetches are capped by whichever is smaller, a fixed ceiling or
whatever's left of the budget, and rounds 2/3 skip outright if too little
budget remains rather than risk going over (those sources already
degrade to neutral gracefully). Verified directly with simulated 4-second
per-fetch latency (32s if fully sequential) — the function still
completed in 8.4s by sacrificing only the least-critical, deepest-chained
fetch (pressure's observation history) while every other source still
succeeded. Also added `elapsedMs` to the response for visibility into
actual execution time going forward, and fixed a scoping bug caught
before shipping: a variable referenced in the error-handling backstop was
declared inside the try block it was meant to protect, which would have
thrown a second, masking error from inside the safety net itself.

### The actual root cause (found after the timeout budget still wasn't enough)

The time budget protected the *fetch* phase, but never touched the
*scoring* phase that runs after — and that's where the real problem was.
`nearestValue` does an O(N) linear scan per lookup, and the scoring loop
calls it roughly 7,000+ times across all signals. Measured directly before
building a fix: at 3,000 data points that's already ~7.8 seconds — more
than the entire time budget — and at 15,000 points it's ~42 seconds,
scaling linearly with however many points a data source happens to return
for the requested area. This was completely unprotected, since it all
happens after every fetch already succeeded within budget.

Two fixes, both suggested by working through this with the user:

1. **A 50×50 mile cap on the analysis area** — if the requested box is
   larger, it's shrunk to 50 miles, centered on the original center point,
   before any fetches happen. Reported back as `areaWasCapped` so the app
   can tell the user their view was reduced, which it now does.
2. **Downsampling every data source to a fixed maximum (40 points per
   axis) immediately after parsing**, regardless of how much data actually
   came back. This is the one that mattered most: measured directly, it
   took the same 3,000/15,000/50,000-point cases from 7.8s/42s/169s down to
   a flat 70-80ms — a 97x to 2,342x improvement — because the lookup cost
   is now bounded by a small constant instead of scaling with the source
   data's size.

Verified end-to-end against the real function (not just the isolated
downsample/lookup benchmark) with a mock that realistically respects the
requested bounding box, the way actual ERDDAP servers do: a wide,
~1,035×1,170 mile request — enough to trigger the area cap — completed in
3.3 seconds with every single source succeeding, across every species.

### Species tuning

The species selector changes the actual weights used in the geometric
mean, split by species type:

**Pelagic** (general/mahi/tuna/wahoo/sailfish) — temp preference, SST
break, chlorophyll edge, eddy proximity, current, and a lesser structure
term (wahoo's structure weight is notably higher — they're drop-off/
seamount oriented among open-water fish).

**Bottom** (snapper/grouper) — a completely different, much smaller signal
set: structure dominates (0.55-0.60), tide-driven current matters a lot
(0.30), temperature is minor. Reflects that these are structure-obsessed
fish, not surface-break hunters — a surface temperature reading is only a
loose proxy for general conditions, not the primary signal.

Every weight profile is verified to sum to exactly 1.0 with a script
before being used, not eyeballed.

### Narratives

Each top spot's explanation is built from that spot's own component
scores — including an honest caveat when other signals are good but the
water temperature is actually outside the target species' range, since
that tension is real and worth surfacing rather than hiding behind a
falsely rosy summary.

### Barometric pressure — trend, not just current reading

Pulled as recent observation history (~24h back) from the nearest NOAA
station, not a single current reading — the trend is the real signal:
falling pressure ahead of a front often means aggressive feeding, a sharp
rise behind one often means the bite shuts down. Blends into the "weather"
modulator alongside wind (60/40 favoring pressure).

### Built to be debugged after deploy

Every data source is fetched independently and defensively — a failure
drops that source to neutral rather than breaking the forecast, and the
response's `sources` object reports exactly what succeeded. The app shows
this as source chips (lit = contributed, dim = didn't) at the bottom of
the forecast panel.

Verified offline before deploy: moon-phase math (checked against known
new/full moon dates), pressure-trend categorization (checked across a
range of deltas), the nearest-value bug fix (checked against a synthetic
mismatched grid), and the geometric-mean convergence behavior (checked
against arithmetic-mean behavior side by side on representative
scenarios). Everything else depends on live data servers, so the real test
is deploying and watching the source chips and the spread of scores.

## Testing locally

```
netlify dev
```

- `http://localhost:8888/.netlify/functions/test-fetch` — base ERDDAP pattern
- `http://localhost:8888/.netlify/functions/forecast?latMin=33&latMax=35&lonMin=-76&lonMax=-74&species=wahoo`
  — raw forecast JSON; check that `cells` actually has varied scores, not
  one repeated number
- The app at `http://localhost:8888` — Forecast tab, pick a species, "Run forecast"

## Notes on honesty / limits

- Weather, tide, pressure, and moon are **area-wide** — they modulate the
  whole forecast rather than varying cell by cell, which is accurate: none
  of these are location-specific at this scale.
- Structure scoring is real (seafloor slope from bathymetry) but coarser
  than the temperature/chlorophyll core. Reef/wreck point layers aren't in
  yet — slope is the structure signal for now.
- Species weights and temperature ranges are research-backed starting
  points, tunable against real catch results over time.
- The convergence design deliberately still ranks and returns spots even
  on a mediocre day, rather than sometimes returning nothing — the best
  *available* option, honestly scored lower, rather than silence.
